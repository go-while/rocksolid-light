    <?php
    include "config.inc.php";
    include ("$file_newsportal"); 
    if(file_exists($config_dir."/nntp.disable")) {
       clearstatcache(true, $config_dir."/nntp.disable");
       $parent_pid = file_get_contents(sys_get_temp_dir().'/rslight-nntp.lock', IGNORE_NEW_LINES);
       posix_kill($parent_pid, SIGTERM);
       exit;
    }
    /**
      * Listens for requests and forks on each connection
      */
    $__server_listening = true;
    //error_reporting(E_ALL);
    set_time_limit(0);
    ob_implicit_flush();
    declare(ticks = 1);
    become_daemon();
    /* nobody/nogroup, change to your host's uid/gid of the non-priv user */

    /* handle signals */
    pcntl_signal(SIGTERM, 'sig_handler');
    pcntl_signal(SIGINT, 'sig_handler');
    pcntl_signal(SIGCHLD, 'sig_handler');

    if(isset($enable_all_networks) && $enable_all_networks === true) {
        $bind="0.0.0.0";
    } else {
        $bind=$local_server;
    }
    server_loop($bind, $local_port);
    
    /**
      * Change the identity to a non-priv user
      */
    function change_identity( $uid, $gid )
    {
        if( !posix_setgid( $gid ) )
        {
            print "Unable to setgid to " . $gid . "!\n";
            exit;
        }

        if( !posix_setuid( $uid ) )
        {
            print "Unable to setuid to " . $uid . "!\n";
            exit;
        }
    }
    /**
      * Creates a server socket and listens for incoming client connections
      * @param string $address The address to listen on
      * @param int $port The port to listen on
      */
    function server_loop($address, $port)
    {
        GLOBAL $__server_listening;
        GLOBAL 
$webserver_user,$logdir,$webserver_uid,$webserver_gid,$installed_path,
$config_path,$groupconfig,$workpath,$path,$spooldir,$nntp_group,$auth_ok;
	$logfile=$logdir.'/nntp.log';
	$lockfile = sys_get_temp_dir() . '/rslight-nntp.lock';
	$pid = file_get_contents($lockfile);
	if (posix_getsid($pid) === false || !is_file($lockfile)) {
	   print "Starting Rocksolid Light NNTP Server...\n";
	   file_put_contents($lockfile, getmypid()); // create lockfile
	} else {
	   print "Rocksolid Light NNTP Server currently running\n";
	   exit;
	}

	$auth_ok = 0;
	$user = "";
	$pass = "";
        if(($sock = socket_create(AF_INET, SOCK_STREAM, 0)) < 0)
        {
            echo "failed to create socket: ".socket_strerror($sock)."\n";
            file_put_contents($logfile, "\n".format_log_date()." failed to create socket: ".socket_strerror($sock), FILE_APPEND); 
	    exit();
        }
        if(($ret = socket_bind($sock, $address, $port)) < 0)
        {
            echo "failed to bind socket: ".socket_strerror($ret)."\n";
            file_put_contents($logfile, "\n".format_log_date()." failed to bind socket: ".socket_strerror($ret), FILE_APPEND); 
	    exit();
        }

        if( ( $ret = socket_listen( $sock, 0 ) ) < 0 )
        {
            echo "failed to listen to socket: ".socket_strerror($ret)."\n";
            file_put_contents($logfile, "\n".format_log_date()." failed to listen to socket: ".socket_strerror($ret), FILE_APPEND);
            exit();
        }

        socket_set_nonblock($sock);

/* Change to non root user */
  $uinfo=posix_getpwnam($webserver_user);
  change_identity($uinfo["uid"],$uinfo["gid"]);
/* Everything below runs as $webserver_user */

        echo "waiting for clients to connect\n";

        while ($__server_listening)
        {
            $connection = @socket_accept($sock);
            if ($connection === false)
            {
                usleep(100);
            }elseif ($connection > 0)
            {
                handle_client($sock, $connection);
            }else
            {
                echo "error: ".socket_strerror($connection);
                file_put_contents($logfile, "\n".format_log_date()." error: ".socket_strerror($connection), FILE_APPEND); 
	        die;
            }
        }
    }

    /**
      * Signal handler
      */
    function sig_handler($sig)
    {
        switch($sig)
        {
            case SIGTERM:
            case SIGINT:
                exit();
            break;

            case SIGCHLD:
                pcntl_waitpid(-1, $status);
            break;
        }
    }

    /**
      * Handle a new client connection
      */
    function handle_client($ssock, $csock)
    {
        GLOBAL $__server_listening;

        $pid = pcntl_fork();

        if ($pid == -1)
        {
            /* fork failed */
            echo "fork failure!\n";
            die;
        }elseif ($pid == 0)
        {
            /* child process */
            $__server_listening = false;
            socket_close($ssock);
            interact($csock);
            socket_close($csock);
        }else
        {
            socket_close($csock);
        }
    }

    function interact($msgsock)
    {
	global 
$logdir,$logfile,$installed_path,$config_path,$groupconfig,$workpath,$path,
$spooldir,$nntp_group,$auth_ok,$user,$pass;

	$workpath=$spooldir."/";
	$path=$workpath."articles/";
	$groupconfig=$spooldir."/spoolnews/groups.txt";

/* END CONFIG */
    $logfile=$logdir.'/nntp.log'; 
    $nntp_group="";
    /* Send instructions. */
    $msg = "200 Rocksolid Light NNTP Server ready (no posting)\r\n";
    socket_write($msgsock, $msg, strlen($msg)); 
    do {   
// DEBUG
//	echo $msg."\r\n";
	$msg="";	
set_time_limit(30);
        if (false === ($buf = socket_read($msgsock, 2048, PHP_NORMAL_READ))) {
            echo "socket_read() failed: reason: " . socket_strerror(socket_last_error($msgsock)) . "\n";
//            file_put_contents($logfile, "\n".format_log_date()." socket_read() failed: reason: " . socket_strerror(socket_last_error($msgsock)), FILE_APPEND); 
	    break;
        }
set_time_limit(0);
        $buf = trim($buf); 
	if (strlen($buf) < 1) {
            continue;
        }
// DEBUG
//	echo $buf."\r\n";
	$command = explode(' ', $buf);
	$command[0] = strtolower($command[0]);
	if(isset($command[1])) {
  	  $command[1] = strtolower($command[1]);
	}
	if ($command[0] == 'date') {
          $msg = '111 '.date('YmdHis')."\r\n";
          socket_write($msgsock, $msg, strlen($msg));
          continue;
        }
	if ($command[0] == 'list') {
	    if(isset($command[1])) {
	        $msg = get_list($command[1]);
            } else {
		$msg = get_list("active");
            } 
            socket_write($msgsock, $msg, strlen($msg));
	    continue;
	}
	if ($command[0] == 'post') {
	    if($auth_ok == 0) {
	        $msg = "480 Posting not permitted\r\n";	
		socket_write($msgsock, $msg, strlen($msg));
                continue;
	    }
	    $msg = "340 Send article to be posted\r\n";
	    $tempfilename = tempnam(sys_get_temp_dir(), '');
	    $tempfilehandle = fopen($tempfilename, 'wb');
	    socket_write($msgsock, $msg, strlen($msg));
	    $buf = socket_read($msgsock, 2048, PHP_NORMAL_READ);
	    $buf = socket_read($msgsock, 2048, PHP_NORMAL_READ);
	    while (trim($buf)  != '.') {
		fwrite($tempfilehandle, $buf);
		$buf = socket_read($msgsock, 2048, PHP_NORMAL_READ);
	    }
	    fclose($tempfilehandle);
	    $msg = process_post($tempfilename);
	    socket_write($msgsock, $msg, strlen($msg));     
	    continue;
	}
	if ($command[0] == 'newgroups') {
            $msg = get_newgroups($command);
            socket_write($msgsock, $msg, strlen($msg));
            continue;
        }
	if ($command[0] == 'authinfo') {
          if($command[1] == 'user') {
            $user = $command[2];
	    if(isset($command[3])) {
		$user = $user." ".$command[3];
	    }
            $msg="381 Enter password\r\n";
	    socket_write($msgsock, $msg, strlen($msg));
            continue;
          } 
	  if ($command[1] == 'pass') {
            if($user == "") {
              $msg="482 Authentication commands issued out of sequence\r\n";
            } else {
              $pass = $command[2];
	      if (check_bbs_auth($user,$pass)) {
	        $auth_ok = 1;
                $msg="281 Authentication succeeded\r\n";
	      } else {
	        $auth_ok = 0;
	        $msg="481 Authentication failed\r\n";
	      }
            }
	    socket_write($msgsock, $msg, strlen($msg));
            continue;
	  }
	  $msg="501 Syntax error\r\n";
          socket_write($msgsock, $msg, strlen($msg));
          continue;
        }
	if ($command[0] == 'mode') {
	    $msg = "200 Rocksolid Light NNRP Server ready (no posting)\r\n";
	    socket_write($msgsock, $msg, strlen($msg));
	    continue;
	}
	if ($command[0] == 'stat') {
            $msg = get_stat($command[1]);
            socket_write($msgsock, $msg, strlen($msg));
            continue;
        }
	if ($command[0] == 'article') {
	    $msg = get_article($command[1], $nntp_group);
	    socket_write($msgsock, $msg, strlen($msg));
	    continue;
	}
	if ($command[0] == 'vichan') {
            $msg = get_vichan_data($command[1], $nntp_group);
            socket_write($msgsock, $msg, strlen($msg));
            continue;
        }
	if ($command[0] == 'head') {
            $msg = get_header($command[1], $nntp_group);
            socket_write($msgsock, $msg, strlen($msg));
            continue;
        }
	if ($command[0] == 'body') {
            $msg = get_body($command[1], $nntp_group);
            socket_write($msgsock, $msg, strlen($msg));
            continue;
        }
	if ($command[0] == 'group') {
	    $nntp_group=$command[1];
	    $msg = get_group($nntp_group);
	    socket_write($msgsock, $msg, strlen($msg));
	    continue;
	}
	if ($command[0] == 'xgtitle') {
            if(isset($command[1])) {
                $msg = get_title($command[1]);
            } else {
                $msg = get_title("active");
            }
            socket_write($msgsock, $msg, strlen($msg));
            continue;
        }	
	if ($command[0] == 'xover') {
	    $msg = get_xover($command[1]);
	    socket_write($msgsock, $msg, strlen($msg));
	    continue;
	}
	if ($command[0] == 'xhdr') {
            $msg = get_xhdr($command[1], $command[2]);
            socket_write($msgsock, $msg, strlen($msg));
            continue;
        }
	if ($command[0] == 'help') {
	    $msg = "100 Sorry, can't help\r\n";
	    socket_write($msgsock, $msg, strlen($msg));
            continue;
        }
	if ($command[0] == 'quit') {
	    $msg = "205 closing connection - goodbye!\r\n";
	    socket_write($msgsock, $msg, strlen($msg));
	    socket_close($msgsock);
            exit(0);
        }
        file_put_contents($logfile, "\n".format_log_date()." ".$msg, FILE_APPEND);
        $talkback = "500 Syntax error or unknown command\r\n";
        socket_write($msgsock, $talkback, strlen($talkback));
      } while (true);    
      exit(0);   
    }

    /**
      * Become a daemon by forking and closing the parent
      */
    function become_daemon()
    {
        $pid = pcntl_fork();
       
        if ($pid == -1)
        {
            /* fork failed */
            echo "fork failure!\n";
            exit();
        }elseif ($pid)
        {
            /* close the parent */
            exit();
        }else
        {
            /* child becomes our daemon */
            posix_setsid();
            chdir('/');
            umask(0);
            return posix_getpid();

        }
    }

function process_post($filename) {
    global $webserver_user,$logfile,$spooldir,$config_dir,$email_tail,$organization;
    $message = file($filename, FILE_IGNORE_NEW_LINES);
    $no_mid=1;
    $no_date=1;
    $no_org=1;
    $is_header=1;
    $ref=0;
    $response="";
    $bytes=0;
    $lines=0;
/* Process post */
    foreach($message as $line) {
	$bytes = $bytes + mb_strlen($line, '8bit');
	if(trim($line) == "" || $lines > 0) {
          $is_header=0;
	  $lines++;
        }
        if($is_header == 0) {
          $body.=$line."\n";
        } else {
	  if(stripos($line, "Date: ") === 0) {
            $finddate=explode(': ', $line);
            $article_date = strtotime($finddate[1]);
	    $no_date=0;
          }
	  if(stripos($line, "Organization: ") !== false) {
	    $no_org=0;
          }
	  if(stripos($line, "Subject: ") !== false) {
            $subject=explode('Subject: ', $line);
	    $ref=0;
          }
	  if(stripos($line, "From: ") === 0) {
            $from=explode(': ', $line);
	    $ref=0;
          }
          if(stripos($line, "Xref: ") === 0) {
            $xref=$line;
            $ref=0;
          }
	  if(stripos($line, "Newsgroups: ") === 0) {
            $ngroups=explode(': ', $line);
	    $newsgroups=$ngroups[1];
	    $ref=0;
          }
	  if(stripos($line, "References: ") === 0) {
            $references_line=explode(': ', $line);
	    $references=$references_line[1];
	    $ref=1;
          }
          if((stripos($line, ':') === false) && (strpos($line, '>'))) {
            if($ref == 1) {
              $references=$references." ".trim($line);
            }
          }
	  if(stripos($line, "Message-ID: ") !== false) {
            $mid=explode(': ', $line);
	    $no_mid=0;
          }
	}
    }
  rewind($message);
/* Find section for posting */
    $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach($menulist as $menu) {
      if($menu[0] == '#') {
        continue;
      }
      $menuitem=explode(':', $menu);
      $glfp=fopen($config_dir.$menuitem[0]."/groups.txt", 'r');
      $section="";
      while($gl=fgets($glfp)) {
	$group_name = preg_split("/( |\t)/", $gl, 2);
	if(stripos(trim($newsgroups), trim($group_name[0])) !== false) {
          $section=$menuitem[0];
	  break 2;
        }
      } 
    }
    fclose($glfp);
    @mkdir($spooldir."/".$section."/outgoing",0755,'recursive');
    $postfilename = tempnam($spooldir.'/'.$section.'/outgoing', '');
    $postfilehandle = fopen($postfilename, 'wb');
    if($no_date == 1) {
      $article_date=time();
      $date_rep = date('D, j M Y H:i:s O', $article_date); 
      fputs($postfilehandle, "Date: ".$date_rep."\r\n");
    } else {
      $date_rep = $finddate[1];
    }
    if($no_org == 1) {
      fputs($postfilehandle, "Organization: ".$organization."\r\n");
    }
    if($no_mid == 1) {
      $identity = $subject[1].",".$from[1].",".$newsgroups[1].",".$references.",".$body;
      $msgid='<'.md5($identity).'$1@'.trim($email_tail,'@').'>';
      fputs($postfilehandle, "Message-ID: ".$msgid."\r\n");
    } else {
      $msgid = $mid[1];
    }
    foreach($message as $line) {
      if(stripos($line, "Newsgroups: ") === 0) {
	fputs($postfilehandle, "Newsgroups: ".$newsgroups."\r\n");
      } else {
	fputs($postfilehandle, $line."\r\n");
      }
    }
    fclose($postfilehandle);
    unlink($filename);
    if($section == "") {
      $response="441 Posting failed (group not found)\r\n";
    } else {
      if($response == "") {
	$post_group=explode(' ', str_replace(',', ' ', $newsgroups));
	foreach($post_group as $onegroup) {
          insert_article($section,$onegroup,$postfilename,$subject[1],$from[1],$article_date,$date_rep,$msgid,$references,$bytes,$lines,$xref);
	}
        $response="240 Article received OK\r\n";
      } 
    }
    return $response;
}

function get_xhdr($header, $articles) {
    global $config_dir,$spooldir,$nntp_group,$workpath,$path;
// By Message-ID
    $tmpgroup=$nntp_group;
    $mid=false;
    if(!is_numeric($articles)) {
      $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      foreach($menulist as $menu) {
        if(($menu[0] == '#') || (trim($menu) == "")) {
          continue;
        }
        $name=explode(":", $menu);
        $overviewdata = file($spooldir."/".$name[0]."-overview", FILE_IGNORE_NEW_LINES);
echo "SEARCHING ".$spooldir."/".$name[0]."-overview\r\n";
        foreach($overviewdata as $overviewline) {
          $articledata = preg_split("/(:#rsl#:|\t)/", $overviewline);
          if(!strcasecmp($articledata[2], $articles)) {
            $tmpgroup=$articledata[0];
            $mid=$articles;
            $articles=$articledata[1];
            break;
          }
        }
      }
    } else {
      if($nntp_group == '') {
        $msg="412 no newsgroup selected\r\n";
        return $msg;
      }
    }
    $thisgroup = $path."/".preg_replace('/\./', '/', $tmpgroup);
    $article_num = explode('-', $articles);
    $first = $article_num[0];
    if(isset($article_num[1]) && is_numeric($article_num[1])) {
      $last = $article_num[1];
    } else {
      if(strpos($articles, "-")) {
        $articles = scandir($thisgroup);
        $ok_article=array();
        foreach($articles as $article) {
          if(!is_numeric($article)) {
            continue;
          }
          $ok_article[]=$article;
        }
        sort($ok_article);
        $last = $ok_article[key(array_slice($ok_article, -1, 1, true))];
        if(!is_numeric($last))
          $last = 0;
      } else {
        $last = $first;
      }
    }
    $msg="221 Header information for ".$header." follows (from articles)\r\n";
    for($i=$first; $i<=$last; $i++) {
      $article_full_path=$thisgroup.'/'.strval($i);
      if(!is_file($article_full_path)) {
        continue;
      }
      $data=extract_header_line($article_full_path, $header);
      if($data !== false) {
        if($mid !== false) {
          $msg.=$mid." ".$data;
        } else {
           $msg.=strval($i)." ".$data;
        }
      }
    }
    $msg.=".\r\n";
    return $msg;
}

function extract_header_line($article_full_path, $header) {
  $thisarticle=file($article_full_path, FILE_IGNORE_NEW_LINES);
  foreach($thisarticle as $thisline) {
    if($thisline == "") {
      $msg2.=".\r\n";
      break;
    }
    if(stripos($thisline, $header) === 0) {
        $content=preg_split("/$header: /i", $thisline);
        return($content[1]."\r\n");
    }
  }
  return(false);
}

function get_title($mode) {
    global $nntp_group,$workpath,$spooldir,$path;
    $mode = strtolower($mode);
    if($mode == "active") {
	$msg="481 descriptions unavailable\r\n";
        return $msg;
    }
    if(!file_exists($spooldir."/".$mode."-title")) {
        $msg="481 descriptions unavailable\r\n";
        return $msg;
    }
    $title = file_get_contents($spooldir."/".$mode."-title", IGNORE_NEW_LINES);
    $msg="282 list of group and description follows\r\n";
    $msg.=$title;

    $msg.=".\r\n";
    return $msg;
}

function get_xover($articles) {
    global $nntp_group,$workpath,$path;
    if($nntp_group == '') {
        $msg="412 no newsgroup selected\r\n";
        return $msg;
    }
    $overviewfile=$workpath.$nntp_group."-overview";
    $article_num = explode('-', $articles);
    $first = $article_num[0];
    if(isset($article_num[1]) && is_numeric($article_num[1]))
        $last = $article_num[1];
    else {
    if(strpos($articles, "-")) {
    $thisgroup = $path."/".preg_replace('/\./', '/', $nntp_group);
    $articles = scandir($thisgroup);
    $ok_article=array();
    foreach($articles as $article) {
    if(!is_numeric($article)) {
        continue;
    }
    $ok_article[]=$article;
    }
    sort($ok_article);
    $last = $ok_article[key(array_slice($ok_article, -1, 1, true))];
    if(!is_numeric($last))
        $last = 0;
    } else {
    $last = $first;
    }
   }
    $msg="224 Overview information follows for articles ".$first." through ".$last."\r\n";
    $overviewfp=fopen($overviewfile, 'r');
    while($overviewline=fgets($overviewfp)) {
      $article=preg_split("/[\s,]+/", $overviewline);
      for($i=$first; $i<=$last; $i++) {
        if($article[0] === strval($i)) {
          $msg.=$overviewline;
        }
      }
    }
    fclose($overviewfp); 
    $msg.=".\r\n";
    return $msg;
}

function get_stat($article) {
    global $nntp_group,$workpath,$path;
    if($nntp_group == '') {
        $msg="412 Not in a newsgroup\r\n";
        return $msg;
    }
    if(!is_numeric($article)) {
	$msg="423 No article number selected\r\n";
	return $msg;
    }
    $overviewfile=$workpath.$nntp_group."-overview";
    $thisgroup = $path."/".preg_replace('/\./', '/', $nntp_group);
    if(!file_exists($thisgroup."/".$article)) {
	$msg="423 No such article number ".$article."\r\n";
	return $msg;
    }
    $overviewfp=fopen($overviewfile, 'r');
    while($overviewline=fgets($overviewfp)) {
      $over=explode("\t", $overviewline);
      if(trim($over[0]) == trim($article)) { 
	$msg="223 ".$article." ".$over[4]." status\r\n";
	fclose(overviewfp);
	return $msg;
      }
    }
    fclose($overviewfp);
    $msg="423 No such article number ".$article."\r\n";
    return $msg;
}

function get_article($article, $nntp_group) {
    global $config_dir,$path,$groupconfig,$config_name,$spooldir;
    $msg2="";
// By Message-ID
// This does not work properly. Fix to search all 'sections'
    if(!is_numeric($article)) {
      $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      foreach($menulist as $menu) {
        if(($menu[0] == '#') || (trim($menu) == "")) {
          continue;
        }
        $name=explode(":", $menu);
        $overviewdata = file($spooldir."/".$name[0]."-overview", FILE_IGNORE_NEW_LINES);
echo "SEARCHING ".$spooldir."/".$name[0]."-overview\r\n";
        foreach($overviewdata as $overviewline) {
// Remove :#rsl#: in 0.6.6 and only use tab
          $articledata = preg_split("/(:#rsl#:|\t)/", $overviewline);
	  if(!strcasecmp($articledata[2], $article)) {
	    $nntp_group=$articledata[0];
	    $article=$articledata[1];
	    break;
	  }
        } 
      }
    } else {
// By article number
      if($nntp_group === "") {
        $msg.="412 no newsgroup has been selected\r\n";
        return $msg;
      }
      if(!is_numeric($article)) {
        $msg.="420 no article has been selected\r\n";
        return $msg;
      }
    } 
    $thisgroup = $path."/".preg_replace('/\./', '/', $nntp_group);
    if(!file_exists($thisgroup."/".$article)) {
        $msg.="430 no such article found\r\n";
        return $msg;
    }
    $thisarticle=file($thisgroup."/".$article, FILE_IGNORE_NEW_LINES);
    foreach($thisarticle as $thisline) {
        if((strpos($thisline, "Message-ID: ") === 0) && !isset($mid[1])) {
          $mid=explode(': ', $thisline);
        }
        $msg2.=$thisline."\r\n";
    }
    $msg="220 ".$article." ".$mid[1]." article retrieved - head and body follow\r\n";
    return $msg.$msg2;
}

function get_header($article, $nntp_group) {
    global $config_dir,$path,$groupconfig,$config_name,$spooldir;
    $msg2="";
// By Message-ID
// This does not work properly. Fix to search all 'sections'
    if(!is_numeric($article)) {
      $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      foreach($menulist as $menu) {
        if(($menu[0] == '#') || (trim($menu) == "")) {
          continue;
        }
        $name=explode(":", $menu);
        $overviewdata = file($spooldir."/".$name[0]."-overview", FILE_IGNORE_NEW_LINES);
echo "SEARCHING ".$spooldir."/".$name[0]."-overview\r\n";
        foreach($overviewdata as $overviewline) {
// Remove :#rsl#: in 0.6.6 and only use tab
          $articledata = preg_split("/(:#rsl#:|\t)/", $overviewline);
          if(!strcasecmp($articledata[2], $article)) {
            $nntp_group=$articledata[0];
            $article=$articledata[1];
            break;
          }
        }
      }
    } else {
// By article number
      if($nntp_group === "") {
        $msg.="412 no newsgroup has been selected\r\n";
        return $msg;
      }
      if(!is_numeric($article)) {
        $msg.="420 no article has been selected\r\n";
        return $msg;
      }
    }
    $thisgroup = $path."/".preg_replace('/\./', '/', $nntp_group);
    if(!file_exists($thisgroup."/".$article)) {
        $msg.="430 no such article found\r\n";
        return $msg;
    }
    $thisarticle=file($thisgroup."/".$article, FILE_IGNORE_NEW_LINES);
    foreach($thisarticle as $thisline) {
	if($thisline == "") {
	  $msg2.=".\r\n";
	  break;
	}
        if((strpos($thisline, "Message-ID: ") === 0) && !isset($mid[1])) {
            $mid=explode(': ', $thisline);
        }
        $msg2.=$thisline."\r\n";
    }
    $msg="221 ".$article." ".$mid[1]." article retrieved - header follows\r\n";
    return $msg.$msg2;
}

function get_vichan_data($article, $nntp_group) {
    global $config_dir,$path,$groupconfig,$config_name,$spooldir;
    $msg2="";
// By Message-ID
// This does not work properly. Fix to search all 'sections'
    if(!is_numeric($article)) {
      $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      foreach($menulist as $menu) {
        if(($menu[0] == '#') || (trim($menu) == "")) {
          continue;
        }
        $name=explode(":", $menu);
        $overviewdata = file($spooldir."/".$name[0]."-overview", FILE_IGNORE_NEW_LINES);
echo "SEARCHING ".$spooldir."/".$name[0]."-overview\r\n";
        foreach($overviewdata as $overviewline) {
// Remove :#rsl#: in 0.6.6 and only use tab
          $articledata = preg_split("/(:#rsl#:|\t)/", $overviewline);
          if(!strcasecmp($articledata[2], $article)) {
            $nntp_group=$articledata[0];
            $article=$articledata[1];
            break;
          }
        }
      }
    } else {
// By article number
      if($nntp_group === "") {
        $msg.="412 no newsgroup has been selected\r\n";
        return $msg;
      }
      if(!is_numeric($article)) {
        $msg.="420 no article has been selected\r\n";
        return $msg;
      }
    }
    $thisgroup = $path."/".preg_replace('/\./', '/', $nntp_group);
    if(!file_exists($thisgroup."/".$article)) {
        $msg.="430 no such article found\r\n";
        return $msg;
    }
    $msg = shell_exec("/etc/rslight/scripts/vichan.php ".$article." ".$nntp_group);
    $msg.="\r\n";
    return $msg;
}

function get_body($article, $nntp_group) {
    global $config_dir,$path,$groupconfig,$config_name,$spooldir;
    $msg2="";
// By Message-ID
// This does not work properly. Fix to search all 'sections'
    if(!is_numeric($article)) {
      $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      foreach($menulist as $menu) {
        if(($menu[0] == '#') || (trim($menu) == "")) {
          continue;
        }
        $name=explode(":", $menu);
        $overviewdata = file($spooldir."/".$name[0]."-overview", FILE_IGNORE_NEW_LINES);
echo "SEARCHING ".$spooldir."/".$name[0]."-overview\r\n";
        foreach($overviewdata as $overviewline) {
// Remove :#rsl#: in 0.6.6 and only use tab
          $articledata = preg_split("/(:#rsl#:|\t)/", $overviewline);
          if(!strcasecmp($articledata[2], $article)) {
            $nntp_group=$articledata[0];
            $article=$articledata[1];
            break;
          }
        }
      }
    } else {
// By article number
      if($nntp_group === "") {
        $msg.="412 no newsgroup has been selected\r\n";
        return $msg;
      }
      if(!is_numeric($article)) {
        $msg.="420 no article has been selected\r\n";
        return $msg;
      }
    }
    $thisgroup = $path."/".preg_replace('/\./', '/', $nntp_group);
    if(!file_exists($thisgroup."/".$article)) {
        $msg.="430 no such article found\r\n";
        return $msg;
    }
    $thisarticle=file($thisgroup."/".$article, FILE_IGNORE_NEW_LINES);
    $body=0;
    foreach($thisarticle as $thisline) {
        if(($thisline == "") && ($body == 0)) {
	  $body=1;
          continue;
        }
        if((strpos($thisline, "Message-ID: ") === 0) && !isset($mid[1])) {
            $mid=explode(': ', $thisline);
        }
	if($body == 1) {
          $msg2.=$thisline."\r\n";
	}
    }
    $msg="222 ".$article." ".$mid[1]." article retrieved - body follows\r\n";
    return $msg.$msg2;
}

function get_group($nntp_group) {
    global $path,$nntp_group,$groupconfig;
    $grouplist = file($groupconfig, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $ok_group=false;
    $count=0;
    foreach($grouplist as $findgroup) {
	$name = preg_split("/( |\t)/", $findgroup, 2);
	$name[0]=strtolower($name[0]);
	$nntp_group=strtolower($nntp_group);
	if(!strcmp($name[0], $nntp_group)) {
	    $ok_group=true;
	    break;
	}
    }
    $thisgroup = $path."/".preg_replace('/\./', '/', $nntp_group);
    if(!is_dir($thisgroup) || $ok_group === false) {
        $msg.="411 no such news group\r\n";
        $nntp_group="";
        return $msg;
    }
    $articles = scandir($thisgroup);
    $ok_article=array();
    foreach($articles as $article) {
	if(!is_numeric($article)) {
	    continue;
	}
	$ok_article[]=$article;
	$count++;
    }
    sort($ok_article);
    $last = $ok_article[key(array_slice($ok_article, -1, 1, true))];
    $first = $ok_article[0];
    if(!is_numeric($last))
        $last = 0;
    if(!is_numeric($first))
        $first = 0;
    $msg="211 ".$count." ".$first." ".$last." ".$nntp_group."\r\n";
    return $msg;    
}

function get_newgroups($mode) {
    global $path,$groupconfig;
    $grouplist = file($groupconfig, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
//  $mode = strtolower($mode);
  $mode = "active";
  if($mode == "active") {
    $msg = '231 list of newsgroups follows'."\r\n";
    foreach($grouplist as $findgroup) {
	$name = preg_split("/( |\t)/", $findgroup, 2);
        if($name[0][0] === ':')
            continue;
        $thisgroup = $path."/".preg_replace('/\./', '/', $name[0]);
        $articles = scandir($thisgroup);
        $ok_article=array();
        foreach($articles as $article) {
            if(!is_numeric($article)) {
                continue;
            }
            $ok_article[]=$article;
        }
        sort($ok_article);
        $last = $ok_article[key(array_slice($ok_article, -1, 1, true))];
        $first = $ok_article[0];
        if(!is_numeric($last))
            $last = 0;
        if(!is_numeric($first))
            $first = 0;
        $msg.=$name[0]." ".$last." ".$first." n\r\n";
    }
  }
  if($mode == "newsgroups") {
    $msg = '215 list of newsgroups and descriptions follows'."\r\n";
    foreach($grouplist as $findgroup) {
      if($findgroup[0] === ':')
        continue;
      $msg.=$findgroup."\r\n";
    }
  }
  if($mode == "overview.fmt") {
    $msg="215 Order of fields in overview database.\r\n";
    $msg.="Subject:\r\n";
    $msg.="From:\r\n";
    $msg.="Date:\r\n";
    $msg.="Message-ID:\r\n";
    $msg.="References:\r\n";
    $msg.="Bytes:\r\n";
    $msg.="Lines:\r\n";
    $msg.="Xref:full\r\n";
  }
  if(isset($msg)) {
    return $msg.".\r\n";
  } else {
    $msg="501 Syntax error or unknown command\r\n";
    return $msg.".\r\n";
  }
}

function get_list($mode) {
    global $path,$spooldir,$groupconfig;
    $grouplist = file($groupconfig, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  $mode = strtolower($mode);
  if($mode == "active") {  
    $msg = '215 list of newsgroups follows'."\r\n";
    foreach($grouplist as $findgroup) {
	$name = preg_split("/( |\t)/", $findgroup, 2);
	if($name[0][0] === ':')
	    continue;
	$thisgroup = $path."/".preg_replace('/\./', '/', $name[0]);
	$articles = scandir($thisgroup);
	$ok_article=array();
	foreach($articles as $article) {
	    if(!is_numeric($article)) {
	        continue;
	    }
	    $ok_article[]=$article;
	}
	sort($ok_article);
	$last = $ok_article[key(array_slice($ok_article, -1, 1, true))];
	$first = $ok_article[0];
	if(!is_numeric($last))
	    $last = 0;
	if(!is_numeric($first))
	    $first = 0;
        $msg.=$name[0]." ".$last." ".$first." y\r\n";
    }
  }
  if($mode == "newsgroups") {
    $msg = '215 list of newsgroups and descriptions follows'."\r\n";
    foreach($grouplist as $findgroup) {
      if($findgroup[0] === ':')
        continue;
      $name = preg_split("/( |\t)/", $findgroup, 2);
      if(trim($name[1]) !== "") {
        $msg.=$findgroup."\r\n";
      } elseif(file_exists($spooldir."/".$name[0]."-title")) {
        $msg.=file_get_contents($spooldir."/".$name[0]."-title", IGNORE_NEW_LINES);
      } else {
        $msg.=$findgroup."\r\n";
      }
    }
  }
  if($mode == "overview.fmt") {
    $msg="215 Order of fields in overview database.\r\n";
    $msg.="Subject:\r\n";
    $msg.="From:\r\n";
    $msg.="Date:\r\n";
    $msg.="Message-ID:\r\n";
    $msg.="References:\r\n";
    $msg.="Bytes:\r\n";
    $msg.="Lines:\r\n";
    $msg.="Xref:full\r\n";
  }
  if(isset($msg)) {
    return $msg.".\r\n";
  } else {
    $msg="501 Syntax error or unknown command\r\n";
    return $msg.".\r\n";
  }
}
function encode_subject($line) {
        $newstring=mb_encode_mimeheader(quoted_printable_decode($line));
        return $newstring;
}

function insert_article($section,$nntp_group,$filename,$subject_i,$from_i,$article_date,
$date_i,$mid_i,$references_i,$bytes_i,$lines_i,$xref_i) {
  global $enable_rslight,$spooldir,$enable_nntp,$logdir,$config_name,$logfile,$pathhost;

  $sn_lockfile = sys_get_temp_dir() . '/'.$section.'-spoolnews.lock';
  $sn_pid = file_get_contents($sn_lockfile);
  if (posix_getsid($sn_pid) === false || !is_file($sn_lockfile)) {
    // Ok to insert 
} else {
    file_put_contents($logfile, "\n".format_log_date()." ".$section." Queuing local post: ".$nntp_group, FILE_APPEND); 
   return(1);
}

  $local_groupfile=$spooldir."/".$config_name."/local_groups.txt";
  $path=$spooldir."/articles/";
  $grouppath = $path.preg_replace('/\./', '/', $nntp_group);
  $nocem_check="@@NCM";
  $article_date=strtotime($date_i); 
  # Check if group exists. Open it if it does
  fputs($ns, "group ".$nntp_group."\r\n");
  $response = line_read($ns);
  if (strcmp(substr($response,0,3),"411") == 0) {
    echo "\n".$response."\n";
    return(1);
  }

	$thisgroup = $grouppath;
        $articles = scandir($thisgroup);
        $ok_article=array();
        foreach($articles as $this_article) {
        if(!is_numeric($this_article)) {
          continue;
        }
        $ok_article[]=$this_article;
        }
        sort($ok_article);
        $local = $ok_article[key(array_slice($ok_article, -1, 1, true))];
	if(!is_numeric($local))
          $local = 0;

  $local++;
  if($local < 1)
    $local = 1;
      if($article_date > time())
        $article_date = time();
      $in_file=fopen($filename, 'r');
      while(is_file($grouppath."/".$local)) {
        $local++;
      }
      $out_file=fopen($grouppath."/".$local, 'w+');
      $header=1;
      while($buf=fgets($in_file)) {
	if((trim($buf) == "") && ($header == 1)) {
	  $buf="Xref: ".$pathhost." ".$nntp_group.":".$local;
	  fputs($out_file, rtrim($buf, "\n\r").PHP_EOL);
	  $xref_i=$buf;
	  $buf="";
	  $header=0;
	}
	fputs($out_file, rtrim($buf, "\n\r").PHP_EOL);
      }
      fputs($out_file, "\n.\n");
      fclose($out_file);
      fclose($in_file);
      touch($grouppath."/".$local, $article_date);
      file_put_contents($logfile, "\n".format_log_date()." ".$section." Inserting local post: ".$nntp_group.":".$local, FILE_APPEND);
// Overview
      $overviewHandle = fopen($spooldir."/".$nntp_group."-overview", 'a');
      fputs($overviewHandle, $local."\t".$subject_i."\t".$from_i."\t".$date_i."\t".$mid_i."\t".$references_i."\t".$bytes_i."\t".$lines_i."\t".$xref_i."\n");
      fclose($overviewHandle);
      $references="";
// overview for search (eventually this will not be used)
        $overview_file=$spooldir."/".$section."-overview";
        file_put_contents($overview_file, 
$nntp_group."\t".$local."\t".$mid_i."\t".$article_date."\t".$from_i
."\t".$subject_i."\n", FILE_APPEND);
// End Overview
      echo "\nInserted: ".$nntp_group." ".$local."\n"; 
  $grouplist = file($local_groupfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  $saveconfig = fopen($local_groupfile, 'w+');
  foreach($grouplist as $savegroup) {
    $name = explode(':', $savegroup);
    if (strcmp($name[0], $nntp_group) == 0) {
      fputs($saveconfig, $nntp_group.":".$local."\n");
    } else {
      fputs($saveconfig, $savegroup."\n");
    }
  }
  fclose($saveconfig);
}
?>
