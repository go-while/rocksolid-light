<?php
#
# The settings at the top of this file must be configured
# manually after installation
#
# Also check the bottom of this file if you have upgraded
# for any new options added
#
# Your REMOTE server (where you pull and send articles)
$remote_server="remote.example.com";
$remote_port=119;

# REMOTE server auth. Account must exist on REMOTE server
$remote_auth_user="username";
$remote_auth_pass="password";

# Local NNTP Server configuration 
# (if disabled, remote server will be used for all connections)
$enable_nntp=true;

# Where to bind the LOCAL server
$local_server="127.0.0.1";
$local_port=119;

# This is the title in your header
$rslight_title="Welcome to My Site";

# This is the title in the browser bar
$title_full="My Site";

#
# Below settings should be configured during install
# Please check to make sure it looks ok
#

# The local account of your webserver user
# Cron job will drop to these privileges if run as root
$webserver_user="<webserver_user>";

# This key is created automatically during installation
$thissitekey="<site_key>";

# This is the username that you allow to post as anonymous
# This account will be created automatically 
# and will be updated if changed 
$anonusername="anonymous";
$anonuserpass="<anonymous_password>";

# LOCAL nntp server auth.
# This account will be created automatically
# and will be updated if changed 
$server_auth_user="localuser";
$server_auth_pass="<local_password>";

/* Spamassassin configuration */

# Set to true to enable checking with spamassassin
$spamassassin=false;
# spamc is required, where is it:
$spamc='spamc';
# Name of group where spam is redirected
$spamgroup="rocksolid.spam";

/* End Spamassassin configuration */

/* Misc configuation */

# Path to php executable
$php_exec="php";

# Your timezone relative to GMT
$timezone=0;

# The default content for the main page 
$default_content="/rocksolid/index.php";

## Options added in 0.6.5b ##

# Enable nocem support?
$enable_nocem=false;

# Groups to monitor for nocem messages (space separated)
$nocem_groups="rocksolid.spam";

## Options added in 0.6.5d ##

# Set '$enable_all_networks=true' to bind to ALL networks
$enable_all_networks=true;

# Enable to create new accounts on demand
$auto_create=false;

# Set a name for your news server
$pathhost="unconfigured";

# Auto return to group after posting?
$auto_return=false;

## Options added in 0.6.5e ##

# Don't display articles in overboard for these groups
$overboard_noshow = array("rocksolid.shared.test", "rocksolid.spam");

# Expire articles in days. Set to zero to disable
$expire_days = 0;

# Verify email addresses by sending a code
$verify_email = false;

# Don't verify email if user is connecting via domain ending in (i2p, onion, etc.)
$no_verify = array("i2p", "onion");

# Truncate display of email addresses in From line
$hide_email = true;

# Server info and credentials for sending email
# (sending mail requires PHPMailer package installed) 
# PHPMailer settings (comment out the version that does not apply)

# PHPMailer 6.0 and above:
$phpmailer['phpmailer'] = '/usr/share/php/libphp-phpmailer/src/PHPMailer.php';
$phpmailer['smtp'] = '/usr/share/php/libphp-phpmailer/src/SMTP.php';

# PHPMailer pre 6.0
# (if using version < 6.0, you must also edit a line in $webdir/common/rsusers.php)
# $phpmailer['phpmailer'] = '/usr/share/php/libphp-phpmailer/class.phpmailer.php';
# $phpmailer['smtp'] = '/usr/share/php/libphp-phpmailer/class.smtp.php';

$mailer = array();
$mailer['host'] = "mail.example.com";
$mailer['port'] = "25";
$mailer['username'] = "server_username";
$mailer['password'] = "server_password";
?>
