<?php

# Your REMOTE server (also see local NNTP Server below):
$remote_server="remote.example.com";
$remote_port=119;

# REMOTE server auth. Account must exist on REMOTE server
$remote_auth_user="username";
$remote_auth_pass="password";

# The local account of your webserver user
# Cron job will drop to these privileges if run as root
$webserver_user="www-data";

# Replace this value with your own random characters
$thissitekey="id]ge%llCsu[]v";

# This is the username that you allow to post as anonymous
# This account will be created automatically 
# You should change this username/password from the default
$anonusername="username";
$anonuserpass="password";

/* Local NNTP Server configuration */

# Enable nntp server
$enable_nntp=true;

# Where to bind the LOCAL server
$local_server="127.0.0.1";
$local_port=119;

# LOCAL nntp server auth.
# This account will be created automatically
# You should change this username/password from the default 
$server_auth_user="username";
$server_auth_pass="password";

/* Spamassassin configuration */

# Set to true to enable checking with spamassassin
$spamassassin=false;
# spamc is required, where is it:
$spamc='spamc';
# Name of group where spam is redirected
$spamgroup="rocksolid.spam";

/* End Spamassassin configuration */

/* Misc configuation */

# Path to php executable
$php_exec="php";

# Your timezone relative to GMT
$timezone=0;

# This is the title in your header 
$rslight_title="Welcome to My Site";

# This is the title in the browser bar 
$title_full="My Site";

# The default content for the main page 
$default_content="/rocksolid/index.php";
?>
