<?php

/* Include top level config file for rslight */
include "rslight.inc.php";

?>
