<?php

# Your REMOTE server (also see local NNTP Server below):
$remote_server="remote.example.com";
$remote_port=119;

# REMOTE server auth. Account must exist on REMOTE server
$remote_auth_user="remoteuser";
$remote_auth_pass="remotepassword";

# The uid/gid of your webserver user
# Cron job will drop to these privileges if run as root
$webserver_user="www-data";

# Replace this value with your own random characters
$thissitekey="ktt*]/ei6[[e4ls";

/*
   This is the usernme that you allow to post as anonymous
   This account must exist on your local server
   Create an account for the username for $anonusername and
   enter the username and password below:
*/
$anonusername="anonymous";
$anonuserpass="password";

/* Local NNTP Server configuration */

# Enable nntp server
$enable_nntp=true;

# Where to bind the LOCAL server
$local_server="localhost";
$local_port=119;

# LOCAL server auth. Account must exist on LOCAL server
$server_auth_user="localuser";
$server_auth_pass="localpassword";

/* Spamassassin configuration */

# Set to true to enable checking with spamassassin
$spamassassin=false;
# spamc is required, where is it:
$spamc='spamc';
# Name of group where spam is redirected
$spamgroup="rocksolid.spam";

/* End Spamassassin configuration */

/* Misc configuation */

// Path to php executable
$php_exec="php";

# Your timezone relative to GMT
$timezone=0;

// This is the title in your header 
$rslight_title="Rocksolid Light";

// This is the title in the browser bar 
$title_full="Rocksolid Light";

/* END OF MAIN CONFIGURATION */

/*
 * Frames (frames is not up to date and probably not so great)
 */

// Set to true to use framed version of rslight
$frames_on=false;

// The default content for the left side 'menu' frame
$default_menu="/rocksolid/index.php";

// The default content for the main 'content' frame
$default_content="/rocksolid/index.php";

if (isset($frames_on) && $frames_on === true) {
  $style_css="style-frames.css";
  $frame['content']="content";
  $frame['menu']="menu";
  $frame['header']="header";
} else {
  $style_css="style.css";
  $frame['content']="_self";
  $frame['menu']="_self";
  $frame['header']="_self";
}
$frame_externallink="_blank";
?>
