<?php
/*  spoolnews NNTP news spool creator
 *  Version: 0.3.0
 *  Download: https://news.novabbs.com/getrslight
 *
 *  E-Mail: retroguy@novabbs.com
 *  Web: https://news.novabbs.com
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

set_time_limit (900);

include "config.inc.php";
include ("$file_newsportal");
 
$remote_groupfile=$spooldir."/".$config_name."/".$remote_server.".txt";
$file_groups=$config_path."groups.txt";
$local_groupfile=$spooldir."/".$config_name."/local_groups.txt";
$logfile=$logdir.'/spoolnews.log';
# Expire is incomplete - please don't use it
$expire_days=1440;

# END MAIN CONFIGURATION
@mkdir($spooldir."/".$config_name,0755,'recursive');

$maxarticles = 10;
$maxfirstrequest = 100;

$workpath=$spooldir."/";
$path=$workpath."articles/";
$overview_file=$workpath.$config_name."-overview";

$lockfile = sys_get_temp_dir() . '/'.$config_name.'-spoolnews.lock';
$pid = file_get_contents($lockfile);
if (posix_getsid($pid) === false || !is_file($lockfile)) {
   print "Starting Spoolnews...\n";
   file_put_contents($lockfile, getmypid()); // create lockfile
} else {
   print "Spoolnews currently running\n";
   exit;
}

# Check for groups file, create if necessary
create_spool_groups($file_groups, $remote_groupfile);
create_spool_groups($file_groups, $local_groupfile);
# Iterate through groups 
$ns=nntp2_open($remote_server, $remote_port);

# Refresh group list
  groups_read($server,$port,1);
  echo "Loaded groups\n";

$grouplist = file($remote_groupfile, FILE_IGNORE_NEW_LINES);
foreach($grouplist as $findgroup) {
  $name = explode(':', $findgroup);
  echo "\nRetrieving articles for: ".$name[0]."...  \r\n";
  get_articles($ns, $name[0]);
#  echo "\nExpiring articles for: ".$name[0]."...  \r\n";
#  expire_articles($name[0]);
}
nntp_close($ns);
#expire_overview();
echo "\nSpoolnews Done\r\n";

function post_articles($ns, $spooldir) {
  global $logfile,$config_name;
  if(!is_dir($spooldir."/".$config_name."/outgoing/")) {
    return "No messages to send\r\n";
  }
  $outgoing_dir = $spooldir."/".$config_name."/outgoing/";
  $messages = scandir($outgoing_dir);
  foreach($messages as $message) {
    if(!is_file($outgoing_dir.$message)) {
      continue;
    }
    echo "Sending: ".$outgoing_dir.$message."\r\n";
    fputs($ns, "POST\r\n");
    $response = line_read($ns);
    if (strcmp(substr($response,0,3),"340") != 0) {
      file_put_contents($logfile, "\n".format_log_date()." ".$config_name." Unexpected response to POST: ".$response, FILE_APPEND);
      return $response;
    } 
    $message_fp = fopen($outgoing_dir.$message, "rb");
    while (($msgline = fgets($message_fp, 4096)) !== false) {
      fputs($ns, $msgline);
    }
    fputs($ns, ".\r\n");
    fclose($message_fp);
    $response = line_read($ns);
    if (strcmp(substr($response,0,3),"240") == 0) {
      unlink($outgoing_dir.$message);
      file_put_contents($logfile, "\n".format_log_date()." ".$config_name." Posted: ".$message.": ".$response, FILE_APPEND);
    } else {
      file_put_contents($logfile, "\n".format_log_date()." ".$config_name." Failed to POST: ".$message.": ".$response, FILE_APPEND);
      continue;
    }
  }
  return "Messages sent\r\n";
}

function get_articles($ns, $group) {
  global $remote_auth_user, $remote_auth_pass, $remote_server, $remote_port, $maxarticles, $maxfirstrequest, $workpath, $path, $remote_groupfile, $local_groupfile, $overview_file, $local, $enable_nntp, $logdir, $config_name, $logfile;
  $grouppath = $path.preg_replace('/\./', '/', $group);
  
  # Check if group exists. Open it if it does
  fputs($ns, "group ".$group."\r\n");
  $response = line_read($ns);
  if (strcmp(substr($response,0,3),"411") == 0) {
    echo "\n".$response."\n";
    return(1);
  }
  
  # Get config
  $grouplist = file($remote_groupfile, FILE_IGNORE_NEW_LINES);
  foreach($grouplist as $findgroup) {
    $name = explode(':', $findgroup);
    if (strcmp($name[0], $group) == 0) {
      if (isset($name[1]))
        $article = $name[1] + 1;
      break;
    }
  }
 if(isset($enable_nntp) && $enable_nntp === true) {
  $grouplist = file($local_groupfile, FILE_IGNORE_NEW_LINES);
  foreach($grouplist as $findgroup) {
    $name = explode(':', $findgroup);
    if (strcmp($name[0], $group) == 0) {
      if (is_numeric($name[1]))
        $local = $name[1];
      else {
	$thisgroup = $path."/".preg_replace('/\./', '/', $group);
        $articles = scandir($thisgroup);
        $ok_article=array();
        foreach($articles as $this_article) {
        if(!is_numeric($this_article)) {
          continue;
        }
        $ok_article[]=$this_article;
        }
        sort($ok_article);
        $local = $ok_article[key(array_slice($ok_article, -1, 1, true))];
	if(!is_numeric($local))
          $local = 0;
      }
      break;
    }
  } 
  if($local < 1)
    $local = 1;
 } 
  # Split group config line to get last article number
  $detail = explode(" ", $response);
  if (!isset($article)) {
    $article = $detail[2];
  }
  if($article < $detail[3] - $maxfirstrequest) {
    $article = $detail[3] - $maxfirstrequest;
  }
  if($article < $detail[2]) {
    $article = $detail[2];
  }
  # Pull articles and save them in our spool
  @mkdir($grouppath,0755,'recursive');
  $i=0;
  while ($article <= $detail[3]) {
      if($enable_nntp !== true){
        $local = $article;
      }
      fputs($ns, "article ".$article."\r\n");
      $response = line_read($ns);
      if (strcmp(substr($response,0,3),"220") != 0) {
	echo "\n".$response."\n";
	$article++;
	continue;
      }
      if(isset($enable_nntp) && $enable_nntp === true){
        while(is_file($grouppath."/".$local)) {
          $local++;
        }
      }
      $articleHandle = fopen($grouppath."/".$local, 'w+');
      $response = line_read($ns);
      $lines=0;
      $bytes=0;
      $ref=0;
      $is_header=1;
      while(strcmp($response,".") != 0) 
      {
	$bytes = $bytes + mb_strlen($response, '8bit');	
	if(trim($response) == "" || $lines > 0) {
	  $is_header=0;
	  $lines++;
	}
	fputs($articleHandle, $response."\n");
       if($is_header == 1) {
	// Find article date
	if(stripos($response, "Date: ") === 0) {
	  $finddate=explode(': ', $response);
	  $article_date = strtotime($finddate[1]);
	}
	// Get overview data
        if(stripos($response, "Message-ID: ") === 0) {
          $mid=explode(': ', $response);
	  $ref=0;
        }
        if(stripos($response, "From: ") === 0) {
          $from=explode(': ', $response);
	  $ref=0;
        }
        if(stripos($response, "Subject: ") === 0) {
          $subject=explode('Subject: ', $response);
	  $ref=0;
        }
	if(stripos($response, "Xref: ") === 0) {
          $xref=$response;
	  $ref=0;
        }
	if(stripos($response, "References: ") === 0) {
	  $this_references=explode('References: ', $response);
	  $references = $this_references[1];
	  $ref=1;
	}
	if((stripos($response, ':') === false) && (strpos($response, '>'))) {
	  if($ref == 1) {
  	    $references=$references.$response;
	  }
	}
       }
       $response=line_read($ns);
      }
      fputs($articleHandle, $response."\n");
      @fclose($articleHandle);
      $lines=$lines-1;
      $bytes = $bytes + ($lines * 2);
      $handle = fopen($overview_file, 'r');
      $duplicate = 0;
      while (($buffer = fgets($handle)) !== false) {
        if (stripos($buffer, $mid[1]) && (stripos($buffer, $group) !== false)) {
	  unlink($grouppath."/".$local);
	  echo "\nDuplicate Message-ID for: ".$group." ".$article."\n";
	  file_put_contents($logfile, "\n".format_log_date()." ".$config_name." Duplicate Message-ID for: ".$group." ".$article, FILE_APPEND);
	  $article++;
	  fclose($handle);
	  $duplicate = 1;
	  break;
	}
      }
      if($duplicate == 1) {
	continue;
      }
// Overview
      $overviewHandle = fopen($workpath.$group."-overview", 'a');
      fputs($overviewHandle, $local."\t".$subject[1]."\t".$from[1]."\t".$finddate[1]."\t".$mid[1]."\t".$references."\t".$bytes."\t".$lines."\t".$xref."\n");
      fclose($overviewHandle);
      $references="";
// overview for search (eventually this will not be used)
	file_put_contents($overview_file, $group.":#rsl#:".$local.":#rsl#:".$mid[1].":#rsl#:".$article_date.":#rsl#:".$from[1].":#rsl#:".$subject[1]."\n", FILE_APPEND);
// End Overview

      if($article_date > time())
        $article_date = time();
      touch($grouppath."/".$local, $article_date);
      echo "\nRetrieved: ".$group." ".$article."\n";
      $i++;
      if($i > $maxarticles)
	break;
      $article++;
      $local++; 
  }
  $article--;
  $local--;
// Update title
      fputs($ns, "XGTITLE ".$group."\r\n");
      $response = line_read($ns);
      $tmp=explode(" ", $response);
      if($tmp[0]=="282") {
        $overviewHandle = fopen($workpath.$group."-title", 'w');
        $response = line_read($ns);
        while(strcmp($response,".") != 0)
        {
          fputs($overviewHandle, $response."\r\n");
          $response = line_read($ns);
        }
        @fclose($overviewHandle);
      }
  thread_load_newsserver($ns,$group,0);
  # Save config
  $grouplist = file($remote_groupfile, FILE_IGNORE_NEW_LINES);
  $saveconfig = fopen($remote_groupfile, 'w+');
  foreach($grouplist as $savegroup) {
    $name = explode(':', $savegroup);
    if (strcmp($name[0], $group) == 0) {
      fputs($saveconfig, $group.":".$article."\n");
    } else {
      fputs($saveconfig, $savegroup."\n");
    }
  }
  fclose($saveconfig);
  $grouplist = file($local_groupfile, FILE_IGNORE_NEW_LINES);
  $saveconfig = fopen($local_groupfile, 'w+');
  foreach($grouplist as $savegroup) {
    $name = explode(':', $savegroup);
    if (strcmp($name[0], $group) == 0) {
      fputs($saveconfig, $group.":".$local."\n");
    } else {
      fputs($saveconfig, $savegroup."\n");
    }
  }
  fclose($saveconfig);
}

function expire_articles($group) {
  global $expire_days, $workpath, $path, $remote_groupfile;
  $grouppath = $path.preg_replace('/\./', '/', $group);

  $oldest = (time() - (86400 * $expire_days));
  if (!is_dir($grouppath)) {
    return(1);
  }
  $allarticles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($grouppath));
  foreach($allarticles as $article) {
     if (is_file($article)) {
       $stats = stat($article);
       if($stats[9] < $oldest) {
         echo "-";
	 unlink($article);
       }
     } 
  }
}

function expire_overview() {
  global $expire_days, $overview_file;

  $oldest = (time() - (86400 * $expire_days));
  rename($overview_file, $overview_file.".processing");
  $previous = file($overview_file.".processing");
  foreach($previous as $line) {
    $getline = explode(":#rsl#:", $line);
    if ($getline[3] > $oldest) {
        file_put_contents($overview_file, $line, FILE_APPEND);
    } else {
        echo "Expiring: ".$getline[0].":".$getline[1]."\n";
    }
  }
  unlink($overview_file.".processing");
}

function create_spool_groups($in_groups, $out_groups) {
  $grouplist = file($in_groups, FILE_IGNORE_NEW_LINES);
  $groupout = fopen($out_groups, "a+");
  foreach($grouplist as $group) {
    if($group[0] == ":") {
      continue;
    }
    $thisgroup = explode(' ', $group);
    fseek($groupout, 0);
    $found=0;
    while (($buffer = fgets($groupout)) !== false) {
      if (stripos($buffer, $thisgroup[0]) !== false) {
        $found = 1;
        break;
      }
    }
    if($found == 0) {
      fwrite($groupout, $thisgroup[0]."\r\n");
      continue;
    }
  }
  fclose($groupout);
  return;
}

function nntp2_open($nserver=0,$nport=0) {
  global $text_error,$remote_auth_user,$remote_auth_pass,$readonly;
  global $remote_server,$remote_port;
  // echo "<br>NNTP OPEN<br>";
  $authorize=((isset($remote_auth_user)) && (isset($remote_auth_pass)) &&
              ($remote_auth_user != ""));
  if ($nserver==0) $nserver=$remote_server;
  if ($nport==0) $nport=$remote_port;
  $ns=@fsockopen($nserver,$nport);
  $weg=line_read($ns);  // kill the first line
  if (substr($weg,0,2) != "20") {
    echo "<p>".$text_error["error:"].$weg."</p>";
    fclose($ns);
    $ns=false;
  } else {
    if ($ns != false) {
      fputs($ns,"MODE reader\r\n");
      $weg=line_read($ns);  // and once more
      if ((substr($weg,0,2) != "20") &&
          ((!$authorize) || ((substr($weg,0,3) != "480") && ($authorize)))) {
        echo "<p>".$text_error["error:"].$weg."</p>";
        fclose($ns);
        $ns=false;
      }
    }
    if ((isset($remote_auth_user)) && (isset($remote_auth_pass)) &&
        ($remote_auth_user != "")) {
      fputs($ns,"AUTHINFO USER $remote_auth_user\r\n");
      $weg=line_read($ns);
      fputs($ns,"AUTHINFO PASS $remote_auth_pass\r\n");
      $weg=line_read($ns);
/* Only check auth if reading and posting same server */
      if (substr($weg,0,3) != "281" && !(isset($post_server)) && ($post_server!="")) {
        echo "<p>".$text_error["error:"]."</p>";
        echo "<p>".$text_error["auth_error"]."</p>";
      }
    }
  }
  if ($ns==false) echo "<p>".$text_error["connection_failed"]."</p>";
  return $ns;
}
?>
