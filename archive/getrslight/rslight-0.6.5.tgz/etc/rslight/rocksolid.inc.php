<?php

/* Include top level config file for rslight */
include "rslight.inc.php";

# Set $readonly=true; to disallow posting
$readonly=false;

# Set $anonuser=true to allow anonymous posting
$anonuser=true;

# This is added to outgoing message headers
$organization="Rocksolid Light";

# This is the 'domain name' added to usernames in outgoing posts
$email_tail="@rslight.i2p";

# What to tack on the end of a post
# Set $postfooter=""; to disable
$postfooter = "Posted on: Rocksolid Light";

# Enable if REMOTE server is a Synchronet server
$synchronet=false;

# No anonymous for tor users. Comment this out to allow anonymous from tor
if (strpos($_SERVER['HTTP_HOST'], 'onion') !== false) {
        $anonuser=false;
		$anonuserpass="false";
}
?>
