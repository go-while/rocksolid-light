<?php

/* Location of configuration and spool */
$config_dir = "/etc/rslight/";
$spooldir = "/var/spool/rslight";

/* Include main config file for rslight */
include $config_dir."rslight.inc.php";
?>
