<?php

include "../common/config.inc.php";

/* Config file name should be the basename
 * of your path where you installed rslight
 * plus .inc.php.
 * So if installed in /var/www/html/rocksolid
 * it's rocksolid.inc.php in $config_dir
 */
$config_name = basename(getcwd());
$config_file = $config_dir.$config_name.".inc.php";
$installed_path = getcwd();

/* $config_path is a directory off the $config_dir
 * where specific files such as groups.txt
 * are located
 */
$config_path = $config_dir.$config_name."/";

include "$config_file";
$logdir=$spooldir.'/log';

ini_set('error_reporting', E_ERROR );

/* Permanent configuration changes */
@mkdir($logdir,0755,'recursive');
@mkdir($spooldir.'/upload',0755,'recursive');

date_default_timezone_set('UTC');
$overboard=true;
$spoolnews=true;
if(isset($enable_nntp) && $enable_nntp === true) {
  $server=$local_server;
  $port=$local_port;
} else {
  $server=$remote_server;
  $port=$remote_port;
}
/*
 * directories and files
 */
$imgdir="img";
$file_newsportal="newsportal.php";
$file_index="index.php";
$file_thread="thread.php";
$file_article="article-flat.php";
$file_article_full="article.php";
$file_attachment="attachment.php";
$file_post="post.php";
$file_cancel="cancel.php";
$file_language="lang/english.lang";
$file_footer="footer.inc";
$file_groups=$config_path."groups.txt";

$title = $title_full;

/*
 * Grouplist Layout
 */
$gl_age=true;

/*
 * Thread layout
 */
# When viewing a thread should the articles be sorted by subthreads, or
# simply by date, oldest to newest?
# Set to false to sort by date, true to sort into subthreads.
# Generally, false makes it easier to find the latest posts at the bottom.
$thread_articles=false;

$thread_treestyle=7;
$thread_show["date"]=false;
$thread_show["subject"]=true;
$thread_show["author"]=false;
$thread_show["authorlink"]=false;
$thread_show["replies"]=false;
$thread_show["lastdate"]=true; // makes only sense with $thread_show["replies"]=false
$thread_show["threadsize"]=true;
$thread_show["latest"]=true;
$thread_maxSubject=70;
$maxarticles=1000;
$maxarticles_extra=50000;
$age_count=3;
$age_time[1]=86400; //24 hours
$age_color[1]="red";
$age_time[2]=259200; //3 days
$age_color[2]="darkgoldenrod";
$age_time[3]=604800; //7 days
$age_color[3]="darkgreen";
$thread_sort_order=-1;
$thread_sort_type="thread";
$articles_per_page=100;
$startpage="first";

/* 
 * article layout 
 */
$article_show["Subject"]=true;
$article_show["From"]=true;
$article_show["Newsgroups"]=true;
$article_show["Followup"]=true;
$article_show["Organization"]=true;
$article_show["Date"]=true;
$article_show["Message-ID"]=false;
$article_show["User-Agent"]=false;
$article_show["References"]=false;
$article_show["From_link"]=true;
//$article_show["From_rewrite"]=array('@',' (at) ');
$article_showthread=true;
$article_graphicquotes=true;

/*
 * settings for the article flat view, if used
 */
$articleflat_articles_per_page=10;
$articleflat_chars_per_articles=10000;

/*
 * Message posting
 */
$send_poster_host=false;
$testgroup=true; // don't disable unless you really know what you are doing!
$validate_email=1;
$setcookies=true;
$anonym_address="AnonUser@retrobbs.rocksolidbbs.com";
$msgid_generate="md5";
$msgid_fqdn=$_SERVER["HTTP_HOST"];
$post_autoquote=false;
$post_captcha=false;

/* 
 * Attachments
 */
$attachment_show=true;
$attachment_delete_alternative=true; // delete non-text mutipart/alternative
$attachment_uudecode=true;  // experimental!

/*
 * Security settings
 */
$block_xnoarchive=false;

/*
 * User registration and database
 */
// $npreg_lib="lib/npreg.inc.php";

/*
 * Cache
 */
$cache_articles=false;  // article cache, experimental!
$cache_index=3600; // cache the group index for one hour before reloading
$cache_thread=0; // cache the thread for one minute reloading

/*
 * Misc 
 */
$cutsignature=true;
$compress_spoolfiles=false;

if(isset($spoolnews) && ($spoolnews === true)) {
    $spoolpath = $spooldir."/articles/";
    $localeol=PHP_EOL.PHP_EOL;
} else {
    $spoolpath = "/var/spool/news/articles/";
    $localeol="\r\n\r\n";
}

// website charset, "koi8-r" for example
//$www_charset = "iso-8859-15";
$www_charset = "utf-8";
// Use the iconv extension for improved charset conversions
$iconv_enable=true;
/*
 * Group specific config 
 */
//$group_config=array(
//  '^de\.alt\.fan\.aldi$' => "aldi.inc",
//  '^de\.' => "german.inc"
//);

/*
 * Do not edit anything below this line
 */
// Load group specifig config files
if((isset($group)) && (isset($group_config))) {
  foreach ($group_config as $key => $value) {
    if (ereg($key,$group)) {
      include $value;
      break;
    }
  }
}

// check the settings
include "lib/check.php";

// load the english language definitions first because some of the other
// definitions are incomplete
include("lang/english.lang"); 
include($file_language);
?>
