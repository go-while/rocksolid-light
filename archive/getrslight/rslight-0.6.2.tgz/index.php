<?php
session_start();
$_SESSION['isframed'] = 1;

include '/etc/rslight/rslight.inc.php';
?>

<html>
	<head>
		<title><?php echo $rslight_title ?></title>
		<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="/common/rslight.css">
	</head>
	<body>
		<iframe name="header" src="/common/header.php" width="99%" height="10%" class="np_frame_header"></iframe>
		<iframe name="menu" src="/rocksolid" width ="20%" height="89%" class="np_frame_menu"></iframe>
		<iframe name="content" src="/rocksolid/thread.php?group=rocksolid.shared.rocksolid" width="79%" height="89%" class="np_frame_content"></iframe>

	</body>
</html>
