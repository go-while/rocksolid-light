<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=<?=$www_charset?>">
<?php
if (file_exists('../common/mods/style.css')) {
  echo '<link rel="stylesheet" type="text/css" href="../common/mods/style.css">';
} else {
  echo '<link rel="stylesheet" type="text/css" href="../common/style.css">';
}
?>
</head>
<body>
<?php

include "config.inc.php";

# $hostname: '{POPaddress:port/pop3}INBOX'
$hostname = '{rocksolidbbs:110/pop3}INBOX';
# $external: Using external POP auth?
$external = 0;
# $workpath: Where to cache users (must be writable by calling program)
$workpath = $config_dir."users/";
$keypath = $config_dir."userconfig/";

# DO NOT EDIT ANYTHING BELOW THIS LINE
$ok = FALSE;
$command = "Login";

$username = $_POST['username'];
$password = $_POST['password'];
$command = $_POST['command'];

echo '<center>';

$thisusername = $username;
$username = strtolower($username);
$userFilename = $workpath.$username;
$keyFilename = $keypath.$username;

# Check all input
if (empty($_POST['username'])) {
  echo "Please enter a Username\r\n";
  echo '<br /><a href="newuser.php">Back</a>';
  exit(2);
}

if ($_POST['password'] !== $_POST['password2']) {
  echo "Your passwords entered do not match\r\n";
  echo '<br /><a href="newuser.php">Back</a>';
  exit(2);
}

# Does user file already exist?
if ($userFileHandle = @fopen($userFilename, 'r'))
{
    if ($command == "Create")
    {
        echo "User:".$thisusername." Already Exists\r\n";
	echo '<br /><a href="newuser.php">Back</a>';
	exit(2);
    }
    $userFileInfo = fread($userFileHandle, filesize($userFilename));
    fclose($userFileHandle);

    # User/Pass is correct
    if (password_verify ( $password , $userFileInfo))
    {
        touch($userFilename);
        $ok = TRUE;
    } else {
        $ok = FALSE;
    }
} else {
    $ok = FALSE;
}

# Ok to log in. User authenticated.
if ($ok)
{
    echo "User:".$thisusername."\r\n";
        exit(0);
}

# Using external authentication
if ($external)
{
    $mbox = @imap_open ( $hostname , $username , $password );
    if ($mbox)
    {
        $ok = TRUE;
        imap_close($mbox);
    }
}

# User is authenticated or to be created. Either way, create the file
if ($ok || ($command == "Create") )
{
    if ($userFileHandle = @fopen($userFilename, 'w+'))
    {
        fwrite($userFileHandle, password_hash($password, PASSWORD_DEFAULT));
        fclose($userFileHandle);
	chmod($userFilename, 0666);
    }
    $newkey = make_key($username);
    if ($userFileHandle = @fopen($keyFilename, 'w+'))
    {
        fwrite($userFileHandle, 'encryptionkey:'.$newkey);
        fclose($userFileHandle);
	chmod($userFilename, 0666);
    }

    echo "User:".$thisusername." Created\r\n";
    echo '<br /><a href="../">Back</a>';
    exit(0);
} else {
    echo "Authentication Failed\r\n";
    exit(1);
}

function make_key($username) {
    $key = openssl_random_pseudo_bytes(44);
    return base64_encode($key);
}

?>
</body>
</html> 
