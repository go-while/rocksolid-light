<?php

/* Location of configuration and spool */
$config_dir = "<config_dir>";
$spooldir = "<spooldir>";

/* Include main config file for rslight */
include $config_dir."rslight.inc.php";
?>
