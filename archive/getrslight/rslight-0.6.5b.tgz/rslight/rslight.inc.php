<?php
#
# The settings at the top of this file must be configured
# manually after installation
#

# Your REMOTE server (where you pull and send articles)
$remote_server="remote.example.com";
$remote_port=119;

# REMOTE server auth. Account must exist on REMOTE server
$remote_auth_user="username";
$remote_auth_pass="password";

# Local NNTP Server configuration 
# (if disabled, remote server will be used for all connections)
$enable_nntp=true;

# Where to bind the LOCAL server
$local_server="127.0.0.1";
$local_port=119;

# This is the title in your header
$rslight_title="Welcome to My Site";

# This is the title in the browser bar
$title_full="My Site";

#
# Below settings should be configured during install
# Please check to make sure it looks ok
#

# The local account of your webserver user
# Cron job will drop to these privileges if run as root
$webserver_user="<webserver_user>";

# This key is created automatically during installation
$thissitekey="<site_key>";

# This is the username that you allow to post as anonymous
# This account will be created automatically 
# and will be updated if changed 
$anonusername="anonymous";
$anonuserpass="<anonymous_password>";

# LOCAL nntp server auth.
# This account will be created automatically
# and will be updated if changed 
$server_auth_user="localuser";
$server_auth_pass="<local_password>";

/* Spamassassin configuration */

# Set to true to enable checking with spamassassin
$spamassassin=false;
# spamc is required, where is it:
$spamc='spamc';
# Name of group where spam is redirected
$spamgroup="rocksolid.spam";

/* End Spamassassin configuration */

/* Misc configuation */

# Path to php executable
$php_exec="php";

# Your timezone relative to GMT
$timezone=0;

# The default content for the main page 
$default_content="/rocksolid/index.php";

## Options added in 0.6.5b ##

# Enable nocem support?
$enable_nocem=false;

# Groups to monitor for nocem messages (space separated)
$nocem_groups="rocksolid.spam";
?>
