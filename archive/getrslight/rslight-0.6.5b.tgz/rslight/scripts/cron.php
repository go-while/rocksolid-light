<?php
// This file runs maintenance scripts and should be executed by cron regularly
  include "config.inc.php";

  $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES);

# Start or verify NNTP server
  if(isset($enable_nntp) && $enable_nntp === true) {
    # Create group list for nntp.php
    $fp1=fopen($spooldir."/".$config_name."/groups.txt", 'w');
      foreach($menulist as $menu) {
      if($menu[0] == '#') {
	continue;
      }
      $menuitem=explode(':', $menu);
      if($menuitem[2] == '1') {
        $in_gl = file($config_dir.$menuitem[0]."/groups.txt");
	foreach($in_gl as $ok_group) {
	  if(($ok_group[0] == ':') || (trim($ok_group) == "")) {
	    continue;
	  }
	  fputs($fp1, $ok_group);
	}
      }
    }
    fclose($fp1);
    exec($php_exec." ".$config_dir."scripts/nntp.php");
  }
/* Change to non root user */
  $uinfo=posix_getpwnam($webserver_user);
  change_identity($uinfo["uid"],$uinfo["gid"]);
/* Everything below runs as $webserver_user */

  @mkdir($spooldir."/log/",0755,'recursive');

if(isset($enable_nocem) && $enable_nocem == true) {
  @mkdir($spooldir."nocem",0755,'recursive');
  exec($php_exec." ".$config_dir."scripts/nocem.php");
}

reset($menulist);
foreach($menulist as $menu) {
  if(($menu[0] == '#') || (trim($menu) == "")) {
    continue;
  }
  $menuitem=explode(':', $menu);
  chdir("../".$menuitem[0]);
# Send articles
  echo "Sending articles\n";
  echo exec($php_exec." ".$config_dir."scripts/send.php");
# Refresh spool
  if(isset($spoolnews) && ($spoolnews === true)) {
    exec($php_exec." ".$config_dir."scripts/spoolnews.php");
    echo "Refreshed spoolnews\n";
  }
}

function change_identity( $uid, $gid )
    {
        if( !posix_setgid( $gid ) )
        {
            print "Unable to setgid to " . $gid . "!\n";
            exit;
        }

        if( !posix_setuid( $uid ) )
        {
            print "Unable to setuid to " . $uid . "!\n";
            exit;
        }
    }
?>
