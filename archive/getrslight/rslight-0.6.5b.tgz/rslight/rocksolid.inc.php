<?php

/* Include top level config file for rslight */
include "rslight.inc.php";

# Set $readonly=true; to disallow posting
$readonly=false;

# Set $anonuser=true to allow anonymous posting
$anonuser=true;

# This is added to outgoing message headers
$organization="Unconfigured rslight site";

# This is the 'domain name' added to usernames in outgoing posts
$email_tail="@example.com";

# What to tack on the end of a post
# Set $postfooter=""; to disable
$postfooter = "Posted on: Unconfigured rslight site";

# Enable if REMOTE server is a Synchronet server
$synchronet=false;
?>
