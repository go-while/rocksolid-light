Installing rslight - a web based news client

This is for version 0.6.4

rslight is based on NewsPortal, which discontinued development in 2008, and was 
developed by Florian Amrhein https://florian-amrhein.de/newsportal/

rslight contains some major code and feature changes, but would not exist 
without NewsPortal as a basis for development.

Requirements:

You will need a web server: rslight has been tested with apache2, lighttpd and 
synchronet web servers

php is required, and your web server must be configured to serve .php. 

php-mbstring (to support other character sets) and sharutils (for uudecode) are 
required. These are the names for Debian packages. Other distributions should 
also provide these in some way.

Installation: 

Extract the .tgz file to a temporary location. This will create the needed 
directories and files.

Since the same release files are meant for installation and upgrading, some 
files are not overwritten. All files ending in .dist are meant to be renamed to 
the file name with .dist removed, or used as a guide to modify your previous 
file. These files are:

index.php.dist
common/header.php.dist
common/style.css.dist
rocksolid/groups.txt.dist
rocksolid/tail.inc.dist
rslight/rocksolid.inc.php.dist
rslight/rslight.inc.php.dist
rslight/spoolnews/spoolnews.php.dist
rslight/spoolnews/groups.txt.dist

A script is provided, 'prepare-new-install.sh' to rename these for you if this 
is a NEW install. It is meant to be run before moving the files/directories 
into place. If this is an UPGRADE, don't run this script, rename and edit the 
files manually.

Now move the three directories 
and one file into place:

common/
rocksolid/
rslight/
index.php

common, rocksolid and index.php should be in your web root. So, if you are 
configured to serve from /var/www/html, it should be:

/var/www/html/common
/var/www/html/rocksolid
/var/www/html/index.php

the directory rslight should be moved to /etc:

/etc/rslight

It is very important that the following directories are readable and writable 
by the web server user:

/var/www/html/rocksolid/spool
/var/www/html/rocksolid/upload
/etc/rslight/users
/etc/rslight/userconfig

If using 'spoolnews', the directory and files in /etc/rslight/spoolnews, must 
be writable by the user running this script, and the created spool directories 
'articles/.*' must be readable by the web server user.

These two files need to be modified to your setup and needs:
/etc/rslight/rslight.inc.php
/etc/rslight/rocksolid.inc.php

The files are commented, and should be fairly easy to configure.

If you wish to use the overboard and do not have a news spool (it won't work 
without a news spool), check the README in /etc/rslight/spoolnews/README and 
configure and run the script 'spoolnews.php' as a cron job. Note, it will take 
a while to catch up on messages, so your overboard will not show the latest 
messages until it's all caught up.

Once all is done, give it a try. If it fails to work, check your 
configuration, check it again, then check your web server log files. If you 
can't get it to work, let us know in rocksolid.shared.nodes and we'll try our 
best to help. 

Retro Guy
retroguy@retrobbs.rocksolidbbs.com
