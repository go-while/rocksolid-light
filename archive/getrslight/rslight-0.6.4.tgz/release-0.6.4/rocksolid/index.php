<?php header("Expires: ".gmdate("D, d M Y H:i:s",time()+7200)." GMT");
session_start();
$_SESSION['starttime'] = time();
$_SESSION['views'] = 0;
$_SESSION['isframed'] = 1;

   include "config.inc.php";
   include "auth.inc";
   include "head.inc"; ?>

<?php
// View Latest button
  if ($overboard) {
    echo '<center>';
    echo '<form target="content" action="overboard.php">';
    echo '<button class="np_button_link" type="submit">view latest messages</button>';
    echo '</form>';
    echo '</center>';
  } else { 
    echo htmlspecialchars($title_full);
  } 
include("$file_newsportal");
flush();
$newsgroups=groups_read($server,$port);
echo '<div class="np_index_groups">';
groups_show($newsgroups);
echo '</div>';
?>

