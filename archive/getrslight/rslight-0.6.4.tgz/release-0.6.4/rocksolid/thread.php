<?php 
//header("Expires: ".gmdate("D, d M Y H:i:s",time()+7200)." GMT");
session_start();

  $rate = ($_SESSION['views'] / (time() - $_SESSION['starttime']));
  if (($rate > .15) && ($_SESSION['views'] > 5)) {
    header("HTTP/1.0 404 Not Found");
    exit(0);
  }

$_SESSION['group'] = $_SERVER['REQUEST_URI'];

include "config.inc.php";
include("$file_newsportal");
include "auth.inc";

// register parameters
$group=_rawurldecode($_REQUEST["group"]);
if(isset($_REQUEST["first"]))
  $first=intval($_REQUEST["first"]);
if(isset($_REQUEST["last"]))
  $last=intval($_REQUEST["last"]);

$title.= ' - '.$group;
include "head.inc";

if((!function_exists("npreg_group_has_read_access") ||
    npreg_group_has_read_access($group)) &&
   (!function_exists("npreg_group_is_visible") ||
    npreg_group_is_visible($group))) {

?>
<script>
    var contentURL=window.location.pathname+window.location.search;
    if ( window.self !== window.top ) {
        /* Great! now we move along */
    } else {
        window.location.href = '../index.php?content='+encodeURIComponent(contentURL);
    }
</script>

<a name="top"></a>

<h1 class="np_thread_headline"><?php echo htmlspecialchars(group_display_name($group)); ?></h1>

<?php
  echo '<table cellpadding="0" cellspacing="0" width="100%" class="np_buttonbar"><tr>';
  if (!$readonly && 
      (!function_exists("npreg_group_has_write_access") ||
       npreg_group_has_write_access($group)))
  {
// New Thread button
    echo '<td>';
    echo '<form action="'.$file_post.'">';
    echo '<input type="hidden" name="group" value="'.urlencode($group).'"/>';
    echo '<button class="np_button_link" type="submit">'.$text_thread["button_write"].'</button>';
    echo '</form>';
    echo '</td>';
  }
// View Latest button
  if ($overboard) {
    echo '<td>';
    echo '<form action="overboard.php">';
    echo '<input type="hidden" name="thisgroup" value="'._rawurlencode($group).'"/>';
    echo '<button class="np_button_link" type="submit">View Latest</button>';
    echo '</form>';
    echo '</td>';
  }
// Newsgroups button (hidden)
    echo '<td>';
    echo '<form action="'.$file_index.'">';
    echo '<button class="np_button_hidden" type="submit">'.$text_thread["button_grouplist"].'</button>';
    echo '</form>';
    echo '</td>';

// $ns=nntp_open($server,$port);
  flush();
  $headers = thread_load($group);
  $article_count=count($headers);
  if ($articles_per_page != 0) { 
    if ((!isset($first)) || (!isset($last))) {
      if ($startpage=="first") {
        $first=1;
        $last=$articles_per_page;
      } else {
        $first=$article_count - (($article_count -1) % $articles_per_page);
        $last=$article_count;
      }
    }
    echo '<td class="np_pages" width="100%" align="right">';
    // Show the replies to an article in the thread view?
    if($thread_show["replies"]) {
      // yes, so the counting of the shown articles is very easy
      $pagecount=count($headers);
    } else {
      // oh no, the replies will not be shown, this makes life hard...
      $pagecount=0;
      if(count($headers>0) && is_array($headers)) {
        foreach($headers as $h) {
          if($h->isAnswer==false)
            $pagecount++;
        }
      }
    }
  
    thread_pageselect($group,$pagecount,$first);
    echo '</td>';
  } else {
    $first=0;
    $last=$article_count;
  }
  echo '</tr></table>';
  thread_show($headers,$group,$first,$last);
} else {
  echo $text_register["no_access_group"];
}

?> 
<font size="1em"><p align="right"><a href="#top"><?php echo $text_thread["button_top"];?></a></p>
</font>
<?php
 include "tail.inc"; 
?>
