<?php
/*  rocksolid overboard - overboard for rslight
 *  Version: 0.2
 *  Download: https://news.novabbs.com/getrslight
 *
 *  E-Mail: retroguy@novabbs.com
 *  Web: https://news.novabbs.com
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
?>

<html>
<head>
<title><?php echo "Rocksolid Overboard"?></title>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset==utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="../common/style.css">
</head>
<body textcolor="black" bgcolor="white">
<?php

include "config.inc.php";
# How many days old should articles be displayed?
if (isset($_GET['thisgroup'])) {
  $article_age = 30;
} else {
  $article_age = 7;
}

# Maximum number of articles to show
$maxarticles = 1000;

# How many characters of the body to display per article
$snippetlength = 240;

# How short of a snippet is ok
$snippetshort = 20;

$spoolpath_regexp = '/'.preg_replace('/\//', '\\/', $spoolpath).'/';
$thissite = '.';

$quotefinder = '>';
if(isset($spoolnews)) {
    $localeol=PHP_EOL.PHP_EOL;
} else {
    $localeol="\r\n\r\n";
}

$groupconfig="./groups.txt";
$cachefile="spool/overboard.cache";

$oldest = (time() - (86400 * $article_age));

if (isset($_GET['thisgroup'])) {
  $grouplist = array();
  $grouplist[0] = _rawurldecode(_rawurldecode($_GET['thisgroup']));
  $cachefile=$cachefile.'.'.$grouplist[0];
} else {
  $grouplist = file($groupconfig, FILE_IGNORE_NEW_LINES);
}

/* If cache is less than ? seconds old, use it */
$stats = stat($cachefile);
if($stats[9] > (time() - 300)) {
  echo file_get_contents($cachefile);
  exit(0);
}

ob_start();
# Iterate through groups

$articles = array();
foreach($grouplist as $findgroup) {
	$groups = explode(" ", $findgroup);
	$findgroup = $groups[0];

	$thisgroup = preg_replace('/\./', '/', $findgroup);
	if (!is_dir($spoolpath.$thisgroup)) {
		continue;
	}
	if ((strpos($thisgroup, 'rocksolid/admin')) || (strpos($thisgroup, 'rocksolid/spam')) || (strpos($thisgroup, '/test')) || (strpos($thisgroup, 'rocksolid/feeds'))) {
        	continue;
    	}
	$stats = stat($spoolpath.$thisgroup);
	if($stats[9] > $oldest) {
		$newarticles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($spoolpath.$thisgroup)); 
		foreach($newarticles as $newarticle) {
			$stats = stat($newarticle);
	         	if($stats[9] > $oldest) {
				$articles[] = $newarticle;
			}
		}
	}
}

if (isset($_GET['thisgroup'])) {
    echo '<h1 class="np_thread_headline">'.$grouplist[0].' (latest)</h1>';
    echo '<table cellpadding="0" cellspacing="0" width="100%" class="np_buttonbar"><tr>';
// Article List button
    echo '<td>';
    echo '<form action="'.$file_thread.'">';
    echo '<input type="hidden" name="group" value="'.$grouplist[0].'"/>';
    echo '<button class="np_button_link" type="submit">'.$text_article["back_to_group"].'</button>';
    echo '</form>';
    echo '</td>';
// Newsgroups button (hidden)
    echo '<td>';
    echo '<form action="'.$file_index.'">';
    echo '<button class="np_button_hidden" type="submit">'.$text_thread["button_grouplist"].'</button>';
    echo '</form>';
    echo '</td>';
    echo '</tr></table>';
} else {
    echo '<h1 class="np_thread_headline">latest messages</h1>';
    echo '<table cellpadding="0" cellspacing="0" width="100%" class="np_buttonbar"><tr>';
// Newsgroups button (hidden)
    echo '<td>';
    echo '<form action="'.$file_index.'">';
    echo '<button class="np_button_hidden" type="submit">'.$text_thread["button_grouplist"].'</button>';
    echo '</form>';
    echo '</td>';
    echo '</tr></table>';
}

$results=0;
$files = array();
foreach($articles as $article) {
    if(is_dir($article)) {
		continue;
    }
    $files[filemtime($article)] = $article;
}
krsort($files);
echo '<table cellspacing="0" width="100%" class="np_results_table">';
foreach($files as $article) {
    $articledata = file_get_contents($article);
    $bodystart = strpos($articledata, $localeol);

    $header = substr($articledata, 0, $bodystart);
    $body = substr($articledata, $bodystart+1);
    $body = substr($body, strpos($body, PHP_EOL));

	if(($multi = strpos($body, 'Content-Type: text/plain')) != false) {
		$bodystart = strpos($body, $localeol);
		$body = substr($body, $bodystart+1);
	    $body = substr($body, strpos($body, PHP_EOL));
	}

    # Find group name and article number
    $group = preg_replace($spoolpath_regexp, '', $article);
    $group = preg_replace('/\//', '.', $group);
    $findme = strrpos($group, '.');
    $groupname = substr($group, 0, $findme);
    $articlenumber = substr($group, $findme+1);

    # Generate link
    $url = $thissite."/article-flat.php?id=".$articlenumber."&group="._rawurlencode($groupname)."#".$articlenumber;
    $groupurl = $thissite."/thread.php?group="._rawurlencode($groupname);
    preg_match('/Subject:.*/', $header, $subject);
    $output = explode("Subject: ",$subject[0]);

    preg_match('/Date:.*/', $header, $articledate);
    $dateoutput = explode("Date: ",$articledate[0]);

    preg_match('/From:.*/', htmlspecialchars($header), $articlefrom);
    $isfrom = explode("From: ", $articlefrom[0]);    
    $articlefrom[0] = $isfrom[1];

    $fromoutput = explode("<", html_entity_decode($articlefrom[0]));
    if(strlen($fromoutput[0]) < 2) { 
	$fromoutput[0] = $articlefrom[0];
    }
    if(($results % 2) != 0){
	echo '<tr class="np_result_line1"><td style="word-wrap:break-word";>';
    } else {
	echo '<tr class="np_result_line2"><td style="word-wrap:break-word";>';
    }
    echo '<p class=np_ob_subject>';
    echo '<b><a href="'.$url.'">'.mb_decode_mimeheader($output[1])."</a></b>\r\n";
    echo '</p><p class=np_ob_group>';
    echo '<a href="'.$groupurl.'">'.$groupname.'</a>';
    echo '</p>';
    echo '<p class=np_ob_posted_date>Posted: '.$dateoutput[1].' by: '.mb_decode_mimeheader($fromoutput[0]).'</p>';

    # Try to display useful snippet
	if($stop=strpos($body, "begin 644 "))
		$body=substr($body, 0, $stop);
    $mysnippet = $body;
    if($bodyend=strrpos($mysnippet, "\n---\n")) {
    	$mysnippet = substr($mysnippet, 0, $bodyend);
    } else {
	    if($bodyend=strrpos($mysnippet, "\n-- ")) {
        	$mysnippet = substr($mysnippet, 0, $bodyend);
		} else {
			if($bodyend=strrpos($mysnippet, "\n.")) {
				$mysnippet = substr($mysnippet, 0, $bodyend);
			} 
		}
	}
    if($quoteend=strrpos($mysnippet, $quotefinder)) {
		if($quoteend > (strlen($mysnippet) - $snippetshort)) {
			$quoteend = (strlen($mysnippet) - $snippetlength);
			if ($quoteend < 0)
				$quoteend = 0;
			$mysnippet = substr($mysnippet, $quoteend);
			$mysnippet = substr($mysnippet, strpos($mysnippet, ' '));
		} else {
       		 	$mysnippet = substr($mysnippet, strrpos($mysnippet, $quotefinder) + 1);
	       		$tempsnippet = substr($mysnippet, strpos($mysnippet, PHP_EOL));
			if(strlen($tempsnippet) >= $snippetshort)
				$mysnippet = $tempsnippet;
		}
    }
    $mysnippet = substr($mysnippet, 0, $snippetlength);
    $snippet = $mysnippet."<br /><br />\r\n";
    $displayresult = explode('<', $snippet);
    $echobody=quoted_printable_decode(mb_decode_mimeheader(highlightStr($displayresult[0], $terms)));
    echo "<p class=np_ob_body>".$echobody."</p><br />\r\n";
    echo '</td></tr>';
    if($results++ > ($maxarticles - 2))
	break;
}
echo '</table>';
echo "<p class=np_ob_tail><b>".$results."</b> recent articles found.</p>\r\n";
#echo "<center><i>Rocksolid Overboard</i> version ".$version;
include "tail.inc";

$thispage = ob_get_contents();

ob_end_clean();

echo $thispage;

$cacheFileHandle = fopen($cachefile, "w+");
fwrite($cacheFileHandle, $thispage);
fclose($cacheFileHandle);

function highlightStr($haystack, $needle) {
    preg_match_all("/$needle+/i", $haystack, $matches);
    if (is_array($matches[0]) && count($matches[0]) >= 1) {
	foreach ($matches[0] as $match) {
	    $haystack = str_replace($match, '<b>'.$match.'</b>', $haystack);
	}
    }
    return $haystack;
}

function _rawurlencode($string) {
    $string = rawurlencode(str_replace('+','%2B',$string));
    return $string;
}

function _rawurldecode($string) {
    $string = rawurldecode(str_replace('%2B','+',$string));
    return $string;
}

?>
</body>
</html>
