<?php
session_start();
$_SESSION['isframed'] = 1;

include '/etc/rslight/rslight.inc.php';
?>

<html>
	<head>
		<title><?php echo $rslight_title ?></title>
		<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
	</head>
	<body>
		<iframe name="header" src="/common/header.php" width="99%" height="10%" style="border:none; background:lightgray;"></iframe>
		<iframe name="menu" src="/rocksolid" width ="20%" height="89%" style="border:none; background:lightgray;"></iframe>
		<iframe name="content" src="/rocksolid/thread.php?group=rocksolid.shared.rocksolid" width="79%" height="89%" style="border:none;"></iframe>

	</body>
</html>
