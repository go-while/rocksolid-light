Installing rslight - a web based news client

rslight is based on NewsPortal, which discontinued development in 2008, and was developed by Florian Amrhein https://florian-amrhein.de/newsportal/

rslight contains some major code and feature changes, but would not exist without NewsPortal as a basis for development.

Requirements:

You will need a web server: rslight has been tested with apache2, lighttpd and synchronet web servers

php is required, and your web server must be configured to serve .php. 

php mbstring
sharutils (for uuencode)

Installation: 

Extracting the .tgz file will create three directories and one file:

common/
rocksolid/
rslight/
index.php

common, rocksolid and index.php should be in your web root. So, if you are configured to serve from /var/www/html, it should be:

/var/www/html/common
/var/www/html/rocksolid
/var/www/html/index.php

the directory rslight should be moved to /etc:

/etc/rslight

It is very important the the following directories are readable and writable by the web server user:

/var/www/html/rocksolid/spool
/var/www/html/rocksolid/upload
/etc/rslight/users

Once everything is moved into place, and permissions set, configure the following two files:

/etc/rslight/rslight.inc.php
/etc/rslight/rocksolid.inc.php

The files are commented, and should be fairly easy to configure.

Once this is done, give it a try. If it fails to work, check your configuration, then check your web server log files. If you can't get it to work, let us know in rocksolid.shared.rocksolid and we'll try our best to help. 

If you need a news server to connect to, just ask in this same group, and we'll get you connected (free).

Retro Guy
retroguy@retrobbs.rocksolidbbs.com





