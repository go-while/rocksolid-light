<?php
include '/etc/rslight/rslight.inc.php';
?>

<html>
	<head>
		<link rel="stylesheet" href="rslight.css">
	</head>
	<body>

<table width="100%" valign="middle">
	<tr>
		<td width="30%">
			<a href="/rocksolid/thread.php?group=rocksolid.shared.rocksolid" target="content"><img src="/common/images/rocksolidlight.png" alt="Rocksolid Light" height="40" width="250"></a>
		</td>
		<td>


<p align="center"><small>
	<font size="5">
	<?php echo $header_title; ?>
	</font>
</small></p>
		</td>
		<td align="right">
			<a href="/common/newuser.php" target="content">register</a>&nbsp;&nbsp;
			<a href="/common/nodelist.html" target="content">nodelist</a>&nbsp;&nbsp;
            <a href="/common/faq.txt" target="content">faq</a>
		</td>
	</tr>
</table>
</body></html>
