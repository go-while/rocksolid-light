<?php

# $hostname: '{POPaddress:port/pop3}INBOX'
$hostname = '{rocksolidbbs:110/pop3}INBOX';
# $external: Using external POP auth?
$external = 0;
# $workpath: Where to cache users (must be writable by calling program)
$workpath = "/etc/rslight/users/";

# DO NOT EDIT ANYTHING BELOW THIS LINE
$ok = FALSE;
$command = "Login";

$username = $_POST['username'];
$password = $_POST['password'];
$command = $_POST['command'];

echo '<center>';

$thisusername = $username;
$username = strtolower($username);
$userFilename = $workpath.$username;

# Check all input
if (empty($_POST['username'])) {
  echo "Please enter a Username\r\n";
  echo '<br /><a href="/common/newuser.php">Back</a>';
  exit(2);
}

if ($_POST['password'] !== $_POST['password2']) {
  echo "Your passwords entered do not match\r\n";
  echo '<br /><a href="/common/newuser.php">Back</a>';
  exit(2);
}

# Does user file already exist?
if ($userFileHandle = @fopen($userFilename, 'r'))
{
    if ($command == "Create")
    {
        echo "User:".$thisusername." Already Exists\r\n";
	echo '<br /><a href="/common/rsintro.html">Back</a>';
	exit(2);
    }
    $userFileInfo = fread($userFileHandle, filesize($userFilename));
    fclose($userFileHandle);

    # User/Pass is correct
    if (password_verify ( $password , $userFileInfo))
    {
        touch($userFilename);
        $ok = TRUE;
    } else {
        $ok = FALSE;
    }
} else {
    $ok = FALSE;
}

# Ok to log in. User authenticated.
if ($ok)
{
    echo "User:".$thisusername."\r\n";
        exit(0);
}

# Using external authentication
if ($external)
{
    $mbox = @imap_open ( $hostname , $username , $password );
    if ($mbox)
    {
        $ok = TRUE;
        imap_close($mbox);
    }
}

# User is authenticated or to be created. Either way, create the file
if ($ok || ($command == "Create") )
{
    if ($userFileHandle = @fopen($userFilename, 'w+'))
    {
        fwrite($userFileHandle, password_hash($password, PASSWORD_DEFAULT));
        fclose($userFileHandle);
	chmod($userFilename, 0666);
    }
    $syncFilename = $workpath.'new/'.$username;
    if ($userFileHandle2 = @fopen($syncFilename, 'w+'))
    {
        fwrite($userFileHandle2, $password);
        fclose($userFileHandle2);
        chmod($syncFilename, 0666);
    }
    echo "User:".$thisusername." Created\r\n";
    echo '<br /><a href="/common/rsintro.html">Back</a>';
    exit(0);
} else {
    echo "Authentication Failed\r\n";
    exit(1);
}

?> 
