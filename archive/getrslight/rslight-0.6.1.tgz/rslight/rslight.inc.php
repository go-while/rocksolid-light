<?php

/* This is the config file for rslight main page and header*/

// This is the title of your site
$rslight_title="Welcome to Rocksolid Light";

// This is the title in the header
$header_title="Welcome to my site";

?>

