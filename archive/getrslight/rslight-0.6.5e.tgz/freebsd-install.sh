#!/usr/local/bin/bash

webroot="/usr/local/www/html"
spoolpath="/var/spool/rslight"
configpath="/etc/rslight"
username="www"

site_key=$(date | md5 | fold -w 16 | head -n 1)

echo
echo "This is the main installation script for Rocksolid Light"
echo "and must be run as root from the root directory of the extracted files"
echo
echo "Select installation directories"
echo

echo "Choose a path for your web root for rslight"
read -p "Use default web root $webroot (y/n)? " default; echo
if [ "${default^^}" != "Y" ]
then
  read -p "Enter web root for rslight: " webroot; echo
fi

echo "Choose a path for your spool files for rslight"
read -p "Use default spool path $spoolpath (y/n)? " default; echo
if [ "${default^^}" != "Y" ]
then
  read -p "Enter spool path for rslight: " spoolpath; echo 
fi
echo "Choose a path for rslight configuration files"
read -p "Use default config path $configpath (y/n)? " default; echo
if [ "${default^^}" != "Y" ]
then
  read -p "Enter config path for rslight: " configpath; echo
fi

echo "Choose username used by your web server"
read -p "Use default username $username (y/n)? " default; echo
if [ "${default^^}" != "Y" ]
then
  read -p "Enter username used by your web server: " username; echo
fi

anonymous_password=$(date | md5 | fold -w 16 | head -n 1)

echo
echo "You have selected the following options:"
echo
echo "Web root: $webroot"
echo "Spool dir: $spoolpath"
echo "Config dir: $configpath"
echo "Web user: $username"
echo
echo "Are you sure you wish to install to these directories now"
echo "and change permissions as necessary to $username? "
echo
read -p "Type 'YES' to create the directories and move files into place: " default; echo

if [ "$default" != "YES" ]
then
  echo exiting...
  exit
fi

echo "Creating directories"
echo -n "$webroot..."
mkdir -p $webroot
echo "done"
echo -n "$spoolpath..."
mkdir -p $spoolpath
echo "done"
echo -n "$configpath..."
mkdir -p $configpath
echo "done"
echo
echo -n "Moving files into place..."
cp index.php $webroot
cp -a common $webroot
cp -a rocksolid $webroot
cp -a spoolnews $webroot
cp -a rslight/* $configpath
echo "done"
echo
echo -n "Setting permissions..."
chown $username $spoolpath
chgrp $username $spoolpath
chown $username "$configpath/users"
chgrp $username "$configpath/users"
chmod 700 "$configpath/users"
chown $username "$configpath/userconfig"
chgrp $username "$configpath/userconfig"
chmod 700 "$configpath/userconfig"
echo "done"

local_password=$(date | md5 | fold -w 16 | head -n 1)

echo
echo -n "Applying configuration..."
sed -i '' -e "s|<spooldir>|$spoolpath/|" $webroot/common/config.inc.php
sed -i '' -e "s|<config_dir>|$configpath/|" $webroot/common/config.inc.php
sed -i '' -e "s|<webserver_user>|$username|" $configpath/rslight.inc.php
sed -i '' -e "s|<site_key>|$site_key|" $configpath/rslight.inc.php
sed -i '' -e "s|<anonymous_password>|$anonymous_password|" $configpath/rslight.inc.php
sed -i '' -e "s|<local_password>|$local_password|" $configpath/rslight.inc.php
sed -i '' -e "s|<phpmailerpath>|/usr/local/share/phpmailer/|" $configpath/rslight.inc.php
echo "done"
echo
echo "Next step is to edit TWO configuration files in $configpath:"
echo "$configpath/rslight.inc.php and"
echo "$configpath/rocksolid.inc.php"
echo
echo Add this to crontab for root to link with your remote server:
echo "*/2 * * * * cd $webroot/spoolnews ; bash -lc \"php $configpath/scripts/cron.php\""
echo
echo "Once your web server is configured to point to $webroot and serve .php files"
echo "give it a try. If you have trouble, feel free to ask for help in rocksolid.nodes.help"
echo 
echo "Installation complete"
