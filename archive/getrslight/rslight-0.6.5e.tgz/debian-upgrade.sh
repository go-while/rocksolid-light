#!/bin/bash

webroot="/var/www/html"
configpath="/etc/rslight"
username="www-data"

echo
echo "This is an UPGRADE script for Rocksolid Light"
echo "Only apply to rslight version 0.6.5a or later"
echo "This script must be run as root from the root directory of the extracted files"
echo
echo "Select installation directories"
echo

echo "Choose a path for your web root for rslight"
read -p "Use default web root $webroot (y/n)? " default; echo
if [ "${default^^}" != "Y" ]
then
  read -p "Enter web root for rslight: " webroot; echo
fi

echo "Choose a path for rslight configuration files"
read -p "Use default config path $configpath (y/n)? " default; echo
if [ "${default^^}" != "Y" ]
then
  read -p "Enter config path for rslight: " configpath; echo
fi

echo "Choose username used by your web server"
read -p "Use default username $username (y/n)? " default; echo
if [ "${default^^}" != "Y" ]
then
  read -p "Enter username used by your web server: " username; echo
fi

echo
echo "You have selected the following options:"
echo
echo "Web root: $webroot"
echo "Config dir: $configpath"
echo "Web user: $username"
echo
echo "Are you sure you wish to overwrite scripts in these directories now"
echo "and change permissions as necessary to $username? "
echo
read -p "Type 'YES' to create the directories and move files into place: " default; echo

if [ "$default" != "YES" ]
then
  echo exiting...
  exit
fi

echo -n "Copying files into place..."
cp index.php $webroot
cp -a rocksolid $webroot
cp -a spoolnews $webroot
cp -a rslight/scripts/* $configpath/scripts
mv $webroot/common/config.inc.php $webroot/common/config.inc.php.BACKUP
cp common/* $webroot/common
mv $webroot/common/config.inc.php.BACKUP $webroot/common/config.inc.php
cp common/config.inc.php $webroot/common/config.inc.php.dist
cp rslight/rslight.inc.php $configpath/rslight.inc.php.dist
cp rslight/spoolnews.inc.php $configpath/spoolnews.inc.php.dist
cp rslight/menu.txt $configpath/menu.txt.dist
mkdir $configpath/spoolnews
cp rslight/spoolnews/groups.txt $configpath/spoolnews/groups.txt.dist
echo "done"
echo
echo "If you see no errors above, upgrade is complete"
echo "Check $configpath for .dist files to see if any changes to your"
echo "config files may be necessary."
echo "If the files don't exist, rename .dist files by removing .dist"
echo 
echo "Please kill the rslight nntp server and allow it to restart"
echo "or just reboot"
echo 
echo "Upgrade complete"
