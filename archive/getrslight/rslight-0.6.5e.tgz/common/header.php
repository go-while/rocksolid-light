<html>
	<head>
<?php
if (basename(getcwd()) == 'mods') {
  $rootdir = "../../";
} else {
  $rootdir = "../";
}

include($rootdir.'common/config.inc.php');
?>
   <script type="text/javascript">
     if (navigator.cookieEnabled)
       document.cookie = "tzo="+ (- new Date().getTimezoneOffset());
   </script>
<?php

$menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES);

if (file_exists($rootdir.'common/mods/style.css')) {
  echo '<link rel="stylesheet" type="text/css" href="'.$rootdir.'common/mods/style.css">';
} else {
  echo '<link rel="stylesheet" type="text/css" href="'.$rootdir.'common/style.css">';
}
if (file_exists($rootdir.'common/mods/images/rocksolidlight.png')) {
  $header_image=$rootdir.'common/mods/images/rocksolidlight.png';
} else {
  $header_image=$rootdir.'common/images/rocksolidlight.png';
}

?>
	</head>
	<body>

<table width="100%" valign="middle">
	<tr>
		<td width="30%">
			<a href="<?php echo $default_content;?>"><img src="<?php echo $header_image ?>" alt="Rocksolid Light" class="responsive_image"></a>
		</td>
		<td>


<p align="center"><small>
	<font class="np_title">
	<?php echo $rslight_title; ?>	
	</font>
</small></p>
		</td>
		<td align="right">
			<a href="<?php echo $rootdir; ?>common/newuser.php">register</a>&nbsp;&nbsp;
			<a href="<?php echo $rootdir; ?>common/nodelist.php">nodelist</a>&nbsp;&nbsp;
			<a href="<?php echo $rootdir; ?>common/faq.txt">faq</a>&nbsp;&nbsp;
		</td>
	</tr>
</table>
<?php
$motd = file_get_contents($config_dir.'motd.txt');
echo '<p align="center">';
echo '<table cellpadding="0" cellspacing="0" class="np_header_bar_large"><tr>';
foreach($menulist as $menu) {
    if($menu[0] == '#') {
      continue;
    }
    $menuitem=explode(':', $menu);
    if($menuitem[1] == '0') { 
      continue;
    }
    echo '<td>';
    echo '<form target="'.$frame['menu'].'" action="'.$rootdir.$menuitem[0].'">';
    echo '<button class="np_header_button_link" type="submit">'.$menuitem[0].'</button>';
    echo '</form>';
    echo '</td>';
}
    echo '</tr></table>';
echo '<table cellpadding="0" cellspacing="0" class="np_header_bar_small"><tr>';

foreach($menulist as $menu) {
    if($menu[0] == '#') {
      continue;
    }
    $menuitem=explode(':', $menu);
    if($menuitem[1] == '0') { 
      continue;
    }
    echo '<td>';
    echo '<form target="'.$frame['content'].'" action="'.$rootdir.$menuitem[0].'">';
    echo '<button class="np_header_button_link" type="submit">'.$menuitem[0].'</button>';
    echo '</form>';
    echo '</td>';
}
    if(strlen($motd) > 0) {
      echo '<div class="np_last_posted_date"><h1 class="np_thread_headline">'.$motd.'</h1></div>';
    }
    echo '</tr></table>';
    echo '</p>';
?>
</body></html>
