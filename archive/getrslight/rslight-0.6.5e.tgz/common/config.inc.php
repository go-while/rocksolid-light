<?php

/* Location of configuration and spool */
$config_dir = "<config_dir>";
$spooldir = "<spooldir>";

/* Include main config file for rslight */
include $config_dir."rslight.inc.php";

foreach($no_verify as $no) {
  if (strlen($_SERVER['HTTP_HOST']) - strlen($no) === strrpos($_SERVER['HTTP_HOST'],$no)) {
    $verify_email = false;
  }
}
?>
