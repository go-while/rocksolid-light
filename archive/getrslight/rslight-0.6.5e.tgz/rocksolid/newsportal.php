<?php
/*  rslight NNTP<->HTTP Gateway
 *  Version: 0.6.x
 *  Download: https://news.novabbs.com/getrslight
 *
 *  Based on Newsportal by Florian Amrhein
 *
 *  E-Mail: retroguy@novabbs.com
 *  Web: https://news.novabbs.com
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

if(file_exists("lib/types.inc.php"))
  include "lib/types.inc.php";
if(file_exists("lib/thread.inc.php"))
  include "lib/thread.inc.php";
if(file_exists("lib/message.inc.php"))
  include "lib/message.inc.php";
if(file_exists("lib/post.inc.php"))
  include "lib/post.inc.php";

/*
 * opens the connection to the NNTP-Server
 *
 * $server: adress of the NNTP-Server
 * $port: port of the server
 */
function nntp_open($nserver=0,$nport=0) {
  global $text_error,$server_auth_user,$server_auth_pass,$readonly;
  global $server,$port;
  // echo "<br>NNTP OPEN<br>";
  $authorize=((isset($server_auth_user)) && (isset($server_auth_pass)) &&
              ($server_auth_user != ""));
  if ($nserver==0) $nserver=$server;
  if ($nport==0) $nport=$port;
  $ns=@fsockopen($nserver,$nport);
  $weg=line_read($ns);  // kill the first line
  if (substr($weg,0,2) != "20") {
    echo "<p>".$text_error["error:"].$weg."</p>";
    fclose($ns);
    $ns=false;
  } else {
    if ($ns != false) {
      fputs($ns,"MODE reader\r\n");
      $weg=line_read($ns);  // and once more
      if ((substr($weg,0,2) != "20") && 
          ((!$authorize) || ((substr($weg,0,3) != "480") && ($authorize)))) {
        echo "<p>".$text_error["error:"].$weg."</p>";
        fclose($ns);
        $ns=false;
      }
    }
    if ((isset($server_auth_user)) && (isset($server_auth_pass)) &&
        ($server_auth_user != "")) {
      fputs($ns,"AUTHINFO USER $server_auth_user\r\n");
      $weg=line_read($ns);
      fputs($ns,"AUTHINFO PASS $server_auth_pass\r\n"); 
      $weg=line_read($ns);
/* Only check auth if reading and posting same server */
      if (substr($weg,0,3) != "281" && !(isset($post_server)) && ($post_server!="")) {
        echo "<p>".$text_error["error:"]."</p>";
        echo "<p>".$text_error["auth_error"]."</p>";
      }
    }
  }
  if ($ns==false) echo "<p>".$text_error["connection_failed"]."</p>";
  return $ns;
}

/*
 * Close a NNTP connection
 *
 * $ns: the handle of the connection
 */
function nntp_close(&$ns) {
  if ($ns != false) {
    fputs($ns,"QUIT\r\n");
    fclose($ns);
  }
}

/*
 * Validates an email adress
 *
 * $address: a string containing the email-address to be validated
 *
 * returns true if the address passes the tests, false otherwise.
 */
function validate_email($address)
{
  global $validate_email;
  $return=true;
  if (($validate_email >= 1) && ($return == true))
/* Need to clean up this regex to work properly with preg_match
    $return = (preg_match('^[-!#$%&\'*+\\./0-9=?A-Z^_A-z{|}~]+'.'@'.
               '[-!#$%&\'*+\\/0-9=?A-Z^_A-z{|}~]+\.'.
               '[-!#$%&\'*+\\./0-9=?A-Z^_A-z{|}~]+$',$address));
*/
    $return = 1;
  if (($validate_email >= 2) && ($return == true)) {
    $addressarray=address_decode($address,"garantiertungueltig");
    $return=checkdnsrr($addressarray[0]["host"],"MX");
    if (!$return) $return=checkdnsrr($addressarray[0]["host"],"A");
  }
  return($return);
}

/*
 * decodes a block of 7bit-data in uuencoded format to it's original
 * 8bit format.
 * The headerline containing filename and permissions doesn't have to
 * be included.
 * 
 * $data: The uuencoded data as a string
 *
 * returns the 8bit data as a string
 *
 * Note: this function is very slow and doesn't recognize incorrect code.
 */
function uudecode_line($line) {
  $data=substr($line,1);
  $length=ord($line[0])-32;
  $decoded="";
  for ($i=0; $i<(strlen($data)>>2); $i++) {
    $pack=substr($data,$i<<2,4);
    $upack="";
    $bitmaske=0;
    for ($o=0; $o<4; $o++) {
      $g=((ord($pack[3-$o])-32));
      if ($g==64) $g=0;
      $bitmaske=$bitmaske | ($g << (6*$o));
    }
    $schablone=255;
    for ($o=0; $o<3; $o++) {
      $c=($bitmaske & $schablone) >> ($o << 3);
      $schablone=($schablone << 8);
      $upack=chr($c).$upack;
    }
    $decoded.=$upack;
  }
  $decoded=substr($decoded,0,$length);
  return $decoded;
}

/*
 * decodes uuencoded Attachments.
 *
 * $data: the encoded data
 *
 * returns the decoded data
 */
function uudecode($data) {
  $d=explode("\n",$data);
  $u="";
  for ($i=0; $i<count($d)-1; $i++)
    $u.=uudecode_line($d[$i]);
  return $u;
}

/*
 * returns the mimetype of an filename
 *
 * $name: the complete filename of a file
 *
 * returns a string containing the mimetype
 */
function get_mimetype_by_filename($name) {
  $ending=strtolower(strrchr($name,"."));
  switch($ending) {
    case ".jpg":
    case ".jpeg":
      $type="image/jpeg";
      break;
    case ".gif":
      $type="image/gif";
      break;
    case ".png":
      $type="image/png";
      break;
    case ".bmp":
      $type="image/bmp";
      break;
    default:
      $type="text/plain";
  }
  return $type;
}

function get_mimetype_by_string($filedata) {
  $f = finfo_open();
  return finfo_buffer($f, $filedata, FILEINFO_MIME_TYPE);
}

/*
 * Test, if the access to a group is allowed. This is true, if $testgroup is
 * false or the groupname is in groups.txt
 *
 * $groupname: name of the group to be checked
 *
 * returns true, if access is allowed
 */
function testGroup($groupname) {
  global $testgroup,$file_groups;
  $groupname=strtolower($groupname);
  if ($testgroup) {
    $gf=fopen($file_groups,"r");
    while (!feof($gf)) {
      $read=trim(line_read($gf));
      $read=preg_replace('/\t/', ' ', $read);
      $read=strtolower($read);
      $pos=strpos($read," ");
      if ($pos != false) {
        if (substr($read,0,$pos)==trim($groupname)) return true;
      } else {
        if ($read == trim($groupname)) return true;
      }
    }
    fclose($gf);
	if($groupname=$spamgroup)
		return true;
	else
		return false;
  } else {
    return true;
  }
}

function testGroups($newsgroups) {
  $groups=explode(",",$newsgroups);
  $count=count($groups);
  $return="";
  $o=0;
  for ($i=0; $i<$count; $i++) {
    if (testgroup($groups[$i]) &&
        (!function_exists("npreg_group_has_write_access") || 
         npreg_group_has_write_access($groups[$i]))) {
      if ($o>0) $return.=",";
      $o++;
      $return.=$groups[$i];
    }
  }
  return($return);
}

/*
 * read one line from the NNTP-server
 */
function line_read(&$ns) {
  if ($ns != false) {
    $t=str_replace("\n","",str_replace("\r","",fgets($ns,1200)));
    return $t;
  }
}

/*
 * Split an internet-address string into its parts. An address string could
 * be for example:
 * - user@host.domain (Realname)
 * - "Realname" <user@host.domain>
 * - user@host.domain
 *
 * The address will be split into user, host (incl. domain) and realname
 *
 * $adrstring: The string containing the address in internet format
 * $defaulthost: The name of the host which should be returned if the
 *               address-string doesn't contain a hostname.
 *
 * returns an hash containing the fields "mailbox", "host" and "personal"
 */
function address_decode($adrstring,$defaulthost) {
  $parsestring=trim($adrstring);
  $len=strlen($parsestring);
  $at_pos=strpos($parsestring,'@');     // find @
  $ka_pos=strpos($parsestring,"(");     // find (
  $kz_pos=strpos($parsestring,')');     // find )
  $ha_pos=strpos($parsestring,'<');     // find <
  $hz_pos=strpos($parsestring,'>');     // find >
  $space_pos=strpos($parsestring,')');  // find ' '
  $email="";
  $mailbox="";
  $host="";
  $personal="";
  if ($space_pos != false) {
    if (($ka_pos != false) && ($kz_pos != false)) {
      $personal=substr($parsestring,$ka_pos+1,$kz_pos-$ka_pos-1);
      $email=trim(substr($parsestring,0,$ka_pos-1));
    }
  } else {
    $email=$adrstring;
  }
  if (($ha_pos != false) && ($hz_pos != false)) {
    $email=trim(substr($parsestring,$ha_pos+1,$hz_pos-$ha_pos-1));
    $personal=substr($parsestring,0,$ha_pos-1);
  }
  if ($at_pos != false) {
    $mailbox=substr($email,0,strpos($email,'@'));
    $host=substr($email,strpos($email,'@')+1);
  } else {
    $mailbox=$email;
    $host=$defaulthost;
  }
  $personal=trim($personal);
  if (substr($personal,0,1) == '"') $personal=substr($personal,1);
  if (substr($personal,strlen($personal)-1,1) == '"')
    $personal=substr($personal,0,strlen($personal)-1);
  $result["mailbox"]=trim($mailbox);
  $result["host"]=trim($host);
  if ($personal!="") $result["personal"]=$personal;
  $complete[]=$result;
  return ($complete);
}

/*
 * Read the groupnames from groups.txt, and get additional informations
 * of the groups from the newsserver
 */
function groups_read($server,$port,$load=0) {
  global $gl_age,$file_groups,$spooldir,$config_name,$cache_index;
  // is there a cached version, and is it actual enough?
  $cachefile=$spooldir.'/'.$config_name.'-groups.dat';
  // if cache is new enough, don't recreate it
  clearstatcache(TRUE, $cachefile);
  if($load == 1 && file_exists($cachefile) && (filemtime($cachefile)+$cache_index>time())) {
    return;
  }
  if(file_exists($cachefile) && $load == 0) {
    // cached file exists and is new enough, so lets read it out.
    $file=fopen($cachefile,"r");
    $data="";
    while(!feof($file)) {
      $data.=fgets($file,1000);
    }
    fclose($file);
    $newsgroups=unserialize($data);
  } else {
    $ns=nntp_open($server,$port);
    if ($ns == false) return false;
    $gf=fopen($file_groups,"r");
    // if we want to mark groups with new articles with colors, wie will later
    // need the format of the overview
    $overviewformat=thread_overview_read($ns);
    while (!feof($gf)) {
      $gruppe=new newsgroupType;
      $tmp=trim(line_read($gf));
      $tmp=preg_replace('/\t/', ' ', $tmp);
      if(substr($tmp,0,1)==":") {
        $gruppe->text=substr($tmp,1);
        $newsgroups[]=$gruppe;  
      } elseif(strlen(trim($tmp))>0) {
        // is there a description in groups.txt?
	$pos=strpos($tmp," ");
        if ($pos != false) {
          // yes.
          $gruppe->name=substr($tmp,0,$pos);
          $desc=substr($tmp,$pos);
        } else {
          // no, get it from the newsserver.
          $gruppe->name=$tmp;
          fputs($ns,"XGTITLE $gruppe->name\r\n");
          $response=line_read($ns);
          if (strcmp(substr($response,0,3),"282") == 0) {
            $neu=line_read($ns);
            do {
              $response=$neu;
              if ($neu != ".") $neu=line_read($ns);
            } while ($neu != ".");
            $desc=strrchr($response,"\t");
            if (strcmp($response,".") == 0) {
              $desc="-";
            }
          } else {
            $desc="";
          }
          if (strcmp(substr($response,0,3),"500") == 0)
            $desc="-";
        }
        if (strcmp($desc,"") == 0) $desc="-";
        $gruppe->description=$desc;
        fputs($ns,"GROUP ".$gruppe->name."\r\n"); 
        $t=explode(" ",line_read($ns));
//RETRO
	if($t[0]=="211")
		$gruppe->count=$t[1];
	else {
		nntp_close($ns);
		$ns=nntp_open($server,$port);
	        if ($ns == false) return false;
		fputs($ns,"GROUP ".$gruppe->name."\r\n");
	        $t=explode(" ",line_read($ns));
		if($t[0]=="211")
                  $gruppe->count=$t[1];
	        else
		  continue;
	}
	// mark group with new articles with colors
        if($gl_age) {
          fputs($ns,'XOVER '.$t[3]."\r\n");
          $tmp=explode(" ",line_read($ns));
          if($tmp[0]=="224") {
            $tmp=line_read($ns);
            if($tmp!=".") {
              $head=thread_overview_interpret($tmp,$overviewformat,$gruppe->name);
              $tmp=line_read($ns);
              $gruppe->age=$head->date;
            }
          }
        }
        if ((strcmp(trim($gruppe->name),"") != 0) &&
            (substr($gruppe->name,0,1) != "#"))
          $newsgroups[]=$gruppe;
      }
    }
    fclose($gf);
    nntp_close($ns);
    // write the data to the cachefile
    $file=fopen($cachefile,"w");
    fputs($file,serialize($newsgroups));
    fclose($file);
  }
  if ($load == 0) {
    return $newsgroups;
  } else {
    return;
  }
}

function groups_show($gruppen) {
  global $gl_age,$frame,$spooldir;
  if ($gruppen == false) return;
  global $file_thread,$text_groups;
  $c = count($gruppen);
  $acttype="keins";
  echo '<table class="np_groups_table" cellspacing="0"><tr class="np_thread_head"><td width="45px" class="np_thread_head">';
  echo 'Latest</td><td style="text-align: center;">Newsgroup</td><td width="8%" class="np_thread_head">Messages</td><td width="20%" class="np_thread_head" >Last Message</td></tr>';
  for($i = 0 ; $i < $c ; $i++) {
    $g = $gruppen[$i];
    if(isset($g->text)) {
      if($acttype!="text") {
        $acttype="text";
      }
    } else {
      if($acttype!="group") {
        $acttype="group";
      }
/* Display group name and description */
      $lineclass="np_thread_line".(($i%2)+1);

      echo '<tr class="'.$lineclass.'"><td style="text-align: center;" class="'.$lineclass.'">';
      echo '<a href="overboard.php?thisgroup='._rawurlencode($g->name).'">'; 
      if(is_file("../common/mods/images/latest.png")) {
        echo '<img src="../common/mods/images/latest.png">';
      } else {
        echo '<img src="../common/images/latest.png">';
      }
      echo '</a>';
      echo '</td>';

      echo '<td class="'.$lineclass.'">';
      echo '<span class="np_group_line_text">';
      echo '<a ';
        echo 'target="'.$frame['content'].'" ';
        echo 'href="'.$file_thread.'?group='._rawurlencode($g->name).'">'.group_display_name($g->name)."</a>\n";
	if($g->description!="-")
        echo '</span><br><p class="np_group_desc">'.$g->description.'</p>';

/* Display article count */
      echo '</td><td class="'.$lineclass.'">';
      if($gl_age)
        $datecolor=thread_format_date_color($g->age);
      echo '<small>';
      if($datecolor!="")
        echo '<font color="'.$datecolor.'">'.$g->count.'</font>';
      else
        echo $g->count;
      echo '</small>';

/* Display latest article info */
    echo '</td><td class="'.$lineclass.'"><div class="np_last_posted_date">';
    $filename = $spooldir."/".urlencode($g->name)."-lastarticleinfo.dat";
    $file=fopen($filename,"r");
    $lastarticleinfo=unserialize(fread($file,filesize($filename)));
    fclose($file);
    echo get_date_interval(date("D, j M Y H:i T",$lastarticleinfo->date));
    $lastarticleinfo->name = ltrim($lastarticleinfo->name, "<");

echo '<table><tr><td>';
    echo '<font class="np_last_posted_date">by: ';
    echo '<a href="result.php?command=search&searchpoint=Poster&terms='.$lastarticleinfo->name.'">'.substr($lastarticleinfo->name,0,15).'</a>';
    echo '</td></tr></table>';

    }
    echo "\n";
    flush();
  }
  echo "</td></div></table>\n";
}

/*
 * print the group names from an array to the webpage
 */
function groups_show_frames($gruppen) {
  global $gl_age,$frame,$spooldir;
  if ($gruppen == false) return;
  global $file_thread,$text_groups;
  $c = count($gruppen);
  echo '<div class="np_index_groupblock">';
  $acttype="keins";
  for($i = 0 ; $i < $c ; $i++) {
    $g = $gruppen[$i];
    if(isset($g->text)) {
      if($acttype!="text") {
        $acttype="text";
        if($i>0)
          echo '</div>';
        echo '<div class="np_index_grouphead">';
      }
      echo $g->text;
    } else {
      if($acttype!="group") {
        $acttype="group";
        if($i>0)
          echo '</div>';
        echo '<div class="np_index_groupblock">';
      }
      echo '<div class="np_index_group">';
      echo '<b><a ';
        echo 'target="'.$frame['content'].'" ';
	echo 'href="'.$file_thread.'?group='._rawurlencode($g->name).'">'.group_display_name($g->name)."</a></b>\n";
      if($gl_age)
        $datecolor=thread_format_date_color($g->age);
      echo '<small>(';
      if($datecolor!="")
        echo '<font color="'.$datecolor.'">'.$g->count.'</font>';
      else
        echo $g->count;
      echo ')</small>';
      if($g->description!="-")
        echo '<br><small>'.$g->description.'</small>';
      echo '</div>';
    }
    echo "\n";
    flush();
  }
  echo "</div></div>\n";
}

/*
 * gets a list of aviable articles in the group $groupname
 */
/*
function getArticleList(&$ns,$groupname) {
  fputs($ns,"LISTGROUP $groupname \r\n");
  $line=line_read($ns);
  $line=line_read($ns);
  while(strcmp($line,".") != 0) {
    $articleList[] = trim($line);
    $line=line_read($ns);
  }
  if (!isset($articleList)) $articleList="-";
  return $articleList;
}
*/

/*
 * Decode quoted-printable or base64 encoded headerlines
 *
 * $value: The to be decoded line
 *
 * returns the decoded line
 */
function headerDecode($value) {
	return mb_decode_mimeheader($value);
}

/*
 * calculates an Unix timestamp out of a Date-Header in an article
 *
 * $value: Value of the Date: header
 *
 * returns an Unix timestamp
 */
function getTimestamp($value) {
  global $timezone;

  return strtotime($value);
}

function parse_header($hdr,$number="") {
  for ($i=count($hdr)-1; $i>0; $i--)
    if (preg_match("/^(\x09|\x20)/",$hdr[$i]))
      $hdr[$i-1]=$hdr[$i-1]." ".ltrim($hdr[$i]);
  $header = new headerType;
  $header->isAnswer=false;
  for ($count=0;$count<count($hdr);$count++) {
    $variable=substr($hdr[$count],0,strpos($hdr[$count]," "));
    $value=trim(substr($hdr[$count],strpos($hdr[$count]," ")+1));
      switch (strtolower($variable)) {
        case "from:": 
          $fromline=address_decode(headerDecode($value),"nirgendwo");
          if (!isset($fromline[0]["host"])) $fromline[0]["host"]="";
          $header->from=$fromline[0]["mailbox"]."@".$fromline[0]["host"];
          $header->username=$fromline[0]["mailbox"];
          if (!isset($fromline[0]["personal"])) {
            $header->name="";
          } else {
            $header->name=$fromline[0]["personal"];
          }
          break;
        case "message-id:":
          $header->id=$value;
          break;
        case "subject:":
          $header->subject=headerDecode($value);
          break;
        case "newsgroups:":
          $header->newsgroups=$value;
          break;
        case "organization:":
          $header->organization=headerDecode($value);
          break;
        case "content-transfer-encoding:":
          $header->content_transfer_encoding=trim(strtolower($value));
          break; 
        case "content-type:":
          $header->content_type=array();
          $subheader=explode(";",$value);
          $header->content_type[0]=strtolower(trim($subheader[0]));
          for ($i=1; $i<count($subheader); $i++) {
            $gleichpos=strpos($subheader[$i],"=");
            if ($gleichpos) {
              $subvariable=trim(substr($subheader[$i],0,$gleichpos));
              $subvalue=trim(substr($subheader[$i],$gleichpos+1));
              if (($subvalue[0]=='"') &&
                  ($subvalue[strlen($subvalue)-1]=='"'))
                $subvalue=substr($subvalue,1,strlen($subvalue)-2);
              switch($subvariable) {
                case "charset":
                  $header->content_type_charset=array(strtolower($subvalue));
                  break;
                case "name":
                  $header->content_type_name=array($subvalue);
                  break;
                case "boundary":
                  $header->content_type_boundary=$subvalue;
                  break;
                case "format":
                  $header->content_type_format=array($subvalue);
              }
            }
          }
          break;
        case "references:":
          $ref=trim($value);
          while (strpos($ref,"> <") != false) {
            $header->references[]=substr($ref,0,strpos($ref," "));
            $ref=substr($ref,strpos($ref,"> <")+2);
          }
          $header->references[]=trim($ref);
          break;
        case "date:":
          $header->date=getTimestamp(trim($value));
          break;
        case "followup-to:":
          $header->followup=trim($value);
          break;
        case "x-newsreader:":
        case "x-mailer:":
	case "x-rslight-to:":
	  $header->rslight_to=trim($value);
	  break;
	case "x-rslight-site:":
	  $header->rslight_site=trim($value);
	  break;
        case "user-agent:":
          $header->user_agent=trim($value);
          break;
        case "x-face:": // not ready
//          echo "<p>-".base64_decode($value)."-</p>";
          break;
        case "x-no-archive:":
          $header->xnoarchive=strtolower(trim($value));
      }
  }
  if (!isset($header->content_type[0]))
    $header->content_type[0]="text/plain";
  if (!isset($header->content_transfer_encoding))
    $header->content_transfer_encoding="8bit";
  if ($number != "") $header->number=$number;
  return $header;
}

/*
 * convert the charset of a text
 */
function recode_charset($text,$source=false,$dest=false) {
  global $iconv_enable,$www_charset;
  if($dest==false)
    $dest=$www_charset;
  if(($iconv_enable) && ($source!=false)) {
    $return=iconv($source,
                 $dest."//TRANSLIT",$text);
    if($return!="")
      return $return;
    else
      return $text;
  } else {
    return $text;
  }
}

function decode_body($body,$encoding) {
  $bodyzeile="";
  switch ($encoding) {
    case "base64":
      $body=base64_decode($body);
      break;
    case "quoted-printable":
      $body=Quoted_printable_decode($body);
      $body=str_replace("=\n","",$body);
//    default:
//      $body=str_replace("\n..\n","\n.\n",$body);
  }

  return $body;
}

/*
 * makes URLs clickable
 *
 * $text: A text-line probably containing links.
 *
 * the function returns the text-line with HTML-Links to the links or
 * email-adresses.
 */
function html_parse($text) {
  global $frame_externallink;
  if ((isset($frame_externallink)) && ($frame_externallink != "")) { 
    $target=' TARGET="'.$frame_externallink.'" ';
  } else {
    $target=' ';
  }
  // regular expressions that will be applied to every word in the text
  $regexp_replace=array(
    'http://((\.*([-a-z0-9_/~@?=%#;+]|&amp;)+)+)' =>
      '<a'.$target.'href="http://\1">http://\1</a>',
    '(www\.[-a-z]+\.(de|pl|cz|sk|tk|tv|cc|cx|biz|us|uk|info|int|eu|dk|org|net|at|ch|com))' =>
      '<a'.$target.'href="http://\1">\1</a>',
    'https://([-a-z0-9_./~@?=%#&;\n]+)' =>
      '<a'.$target.'href="https://\1">https://\1</a>',
    'gopher://([-a-z0-9_./~@?=%\n]+)' =>
      '<a'.$target.'href="gopher://\1">gopher://\1</a>',
    'news://([-a-z0-9_./~@?=%\n]+)' =>
      '<a'.$target.'href="news://\1">news://\1</a>',
    'ftp://([-a-z0-9_./~@?=%\n]+)' =>
      '<a'.$target.'href="ftp://\1">ftp://\1</a>',
    //'([-a-z0-9_./n]+)@([-a-z0-9_.]+)' =>
    //  $_SESSION["loggedin"]!==true ? '(e-Mail)' :
    //  '<a href="mailto:\1@\2">\1@\2</a>'
  );
  $ntext="";
  // split every line into it's words
  $words=explode(" ",$text);
  $n=count($words);
  for($i=0; $i<$n; $i++) {
    $word=$words[$i];
    // test, if we need the slow walk through all the regular expressions
    if(preg_match('/www|\:|@/i',$word)) {
      // apply the regular expressions to the word until a matching 
      // expression is found
      foreach ($regexp_replace as $key => $value) {
        $nword=preg_replace('/{$key}/i',$value,$word);
        if($nword!=$word) {
          $word=$nword;
          break;
        }
      }
    }
    // add the spaces between the words
    if($i>0)
      $ntext.=" ";
    $ntext.=$word;
  }
  return($ntext);
}


/*
 * read the header of an article in plaintext into an array
 * $articleNumber can be the number of an article or its message-id.
 */
function readPlainHeader(&$ns,$group,$articleNumber) {
  fputs($ns,"GROUP $group\r\n");
  $line=line_read($ns);
  fputs($ns,"HEAD $articleNumber\r\n");
  $line=line_read($ns);
  if (substr($line,0,3) != "221") {
    echo $text_error["article_not_found"];
    $header=false;
  } else {
    $line=line_read($ns);
    $body="";
    while(strcmp(trim($line),".") != 0) {
      $body .= $line."\n";
      $line=line_read($ns);
    }
    return explode("\n",str_replace("\r\n","\n",$body));
  }
}

/*
 * cancel an article on the newsserver
 *
 * DO NOT USE THIS FUNCTION, IF YOU DON'T KNOW WHAT YOU ARE DOING!
 *
 * $ns: The handler of the NNTP-Connection
 * $group: The group of the article
 * $id: the Number of the article inside the group or the message-id
 */
function message_cancel($subject,$from,$newsgroups,$ref,$body,$id) {
  global $server,$port,$send_poster_host,$organization,$text_error;
  global $www_charset;
  flush();
  $ns=nntp_open($server,$port);
  if ($ns != false) {
    fputs($ns,"POST\r\n");
    $weg=line_read($ns);
    fputs($ns,'Subject: '.quoted_printable_encode($subject)."\r\n");
    fputs($ns,'From: '.$from."\r\n");
    fputs($ns,'Newsgroups: '.$newsgroups."\r\n");
    fputs($ns,"Mime-Version: 1.0\r\n");
    fputs($ns,"Content-Type: text/plain; charset=".$www_charset."\r\n");
    fputs($ns,"Content-Transfer-Encoding: 8bit\r\n");
    if ($send_poster_host)
      fputs($ns,'X-HTTP-Posting-Host: '.gethostbyaddr(getenv("REMOTE_ADDR"))."\r\n");
    if ($ref!=false) fputs($ns,'References: '.$ref."\r\n");
    if (isset($organization))
      fputs($ns,'Organization: '.quoted_printable_encode($organization)."\r\n");
    fputs($ns,"Control: cancel ".$id."\r\n");
    $body=str_replace("\n.\r","\n..\r",$body);
    $body=str_replace("\r",'',$body);
    $b=explode("\n",$body);
    $body="";
    for ($i=0; $i<count($b); $i++) {
      if ((strpos(substr($b[$i],0,strpos($b[$i]," ")),">") != false ) | (strcmp(substr($b[$i],0,1),">") == 0)) {
        $body .= textwrap(stripSlashes($b[$i]),78,"\r\n")."\r\n";
      } else {
        $body .= textwrap(stripSlashes($b[$i]),74,"\r\n")."\r\n";
      }
    }
    fputs($ns,"\r\n".$body."\r\n.\r\n");
    $message=line_read($ns);
    nntp_close($ns);
  } else {
    $message=$text_error["post_failed"];
  }
  return $message;
}
function rslight_encrypt($data, $key) {
    $encryption_key = base64_decode($key);
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

function _rawurlencode($string) {
    $string = rawurlencode(str_replace('+','%2B',$string));
    return $string;
}

function _rawurldecode($string) {
    $string = rawurldecode(str_replace('%2B','+',$string));
    return $string;
}

function rslight_decrypt($data, $key) {
    $encryption_key = base64_decode($key);
    list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
}

function group_display_name($gname)
{
      if(isset($frames_on) && $frames_on === true) {
        $newname=$gname;
        $newname=str_replace("rocksolid.shared.","",$newname);
		$newname=str_replace("rocksolid.nodes","nodes",$newname);
		$newname=str_replace("rocksolid.feeds.","",$newname);
		$newname=str_replace("rocksolid.","",$newname);
		$newname=str_replace("gmane.","",$newname);
		$newname=str_replace("DOVE-Net.","",$newname);
        return ($newname);
      } else {
        return $gname;
      }
}
function check_bbs_auth($username, $password) {
  global $config_dir,$anonusername,$anonuserpass,$server_auth_user,$server_auth_pass,$auto_create;

  $workpath = $config_dir."users/";
  $username = trim(strtolower($username));
  $userFilename = $workpath.$username;
  $keyFilename = $config_dir."/userconfig/".$username;

// Create accounts for $anonymous and $server_auth_user if not exist  
  if($username == strtolower($anonusername)) {
    if(filemtime($config_dir."rslight.inc.php") > filemtime($userFilename)) {
      if ($userFileHandle = @fopen($userFilename, 'w+'))
      {
        fwrite($userFileHandle, password_hash($anonuserpass, PASSWORD_DEFAULT));
        fclose($userFileHandle);
      }
    }
  }
  if($username == strtolower($server_auth_user)) { 
    if(filemtime($config_dir."rslight.inc.php") > filemtime($userFilename)) {
      if ($userFileHandle = @fopen($userFilename, 'w+'))
      {
        fwrite($userFileHandle, password_hash($server_auth_pass, PASSWORD_DEFAULT));
        fclose($userFileHandle);
      }
    }
  }

  if ($userFileHandle = @fopen($userFilename, 'r'))
  {
        $userFileInfo = fread($userFileHandle, filesize($userFilename));
        fclose($userFileHandle);
        if (password_verify ( $password , $userFileInfo))
        {
                touch($userFilename);
                $ok = TRUE;
        } else {
                return FALSE;
        }
  } else {
        $ok = FALSE;
  }
  if ($ok)
  {
        return TRUE;
  } else {
	if(isset($auto_create) && $auto_create === true) {
	  if ($userFileHandle = @fopen($userFilename, 'w+')) {
            fwrite($userFileHandle, password_hash($password, PASSWORD_DEFAULT));
            fclose($userFileHandle);
            chmod($userFilename, 0666);
          }
          $newkey = base64_encode(openssl_random_pseudo_bytes(44));
          if ($userFileHandle = @fopen($keyFilename, 'w+')) {
            fwrite($userFileHandle, 'encryptionkey:'.$newkey);
            fclose($userFileHandle);
            chmod($userFilename, 0666);
          } 
	  return TRUE;
	} else {
	  return FALSE;
	}
  }
}
function check_encryption_groups($request) {
  global $config_path;
  $groupsFilename = $config_path."encryption_ok.txt";
  if ($groupsFileHandle = @fopen($groupsFilename, 'r'))
  {
    while (!feof($groupsFileHandle))
    {
      $buffer = fgets($groupsFileHandle);
      $buffer = str_replace(array("\r", "\n"), '',$buffer);
        if(!strcmp($buffer, $request)) {
	  fclose($groupsFileHandle);
	  return TRUE;
	}
    }
    fclose($userFileHandle);
  } else {
    return FALSE;
  }
}

function get_user_config($username,$request) {
  global $config_dir;
  $userconfigpath = $config_dir."userconfig/";
  $username = strtolower($username);
  $userFilename = $userconfigpath.$username;

  if ($userFileHandle = @fopen($userFilename, 'r'))
  {
    while (!feof($userFileHandle))
    {
      $buffer = fgets($userFileHandle);
      if(strpos($buffer, $request.':') !== FALSE) {
        $userdataline=$buffer;
        fclose($userFileHandle);
        $userdatafound = explode(':',$userdataline);
        return $userdatafound[1];
      }
    }
    fclose($userFileHandle);
    return FALSE;
  } else {
    return FALSE;
  }
}

function check_spam($subject,$from,$newsgroups,$ref,$body,$msgid)
{
  global $msgid_generate,$msgid_fqdn;
  global $thissitekey,$spamgroup,$spamc;
  $spamfile = tempnam('./spool', 'spam-');

  $tmpheader='From: '.$from."\r\n";
  if(strpos($from, $anonusername)) {
    $tmpheader.="Anonymous: TRUE\r\n";
  }
  $tmpheader.='Message-ID: '.$msgid."\r\n";
  $tmpheader.='Subject: '.encode_subject($subject)."\r\n\r\n";
  if ($spamFileHandle = fopen($spamfile, 'w'))
  {
    fwrite($spamFileHandle, $tmpheader);
    fwrite($spamFileHandle, $body);
    $spamcommand = $spamc.' -E < '.$spamfile;
    ob_start();
    $spamresult = passthru($spamcommand, $res);
    $spamresult = ob_get_contents();
    ob_end_clean();
	$spam_fail=1;
		foreach (explode(PHP_EOL, $spamresult) as $line) {
			$line = str_replace(array("\n\r", "\n", "\r"), '', $line);
			if(strpos($line, 'X-Spam-Checker-Version:') !== FALSE) {
				$spamcheckerversion = $line;
				$spam_fail=0;
			}
			if(strpos($line, 'X-Spam-Level:') !== FALSE) {
                $spamlevel = $line;
            }
		}
    }
    fclose($spamFileHandle);
    unlink($spamfile);
	return array(
		'res' => $res,
		'spamresult' => $spamresult,
		'spamcheckerversion' => $spamcheckerversion,
		'spamlevel' => $spamlevel,
		'spam_fail' => $spam_fail
	);
}

function format_log_date() {
    return date('M d H:i:s');
}

function truncate_email($address) {
    $before_at = explode('@', $address);
      $namelen = strlen($before_at[0]);
      if ($namelen > 3) {
        $endname = $namelen - 3;
        if($endname > 8)
          $endname = 8;
        if($endname < 3)
          $endname++;
        if($endname < 3)
          $endname++;
      } else {
        $endname = $namelen;
      }
      return substr($before_at[0], 0, $endname).'...'.substr($address, $namelen, strlen($address));
}

function get_date_interval($value) {
    $current = time();
    $datetime1 = date_create($value);
    $datetime2 = date_create("@$current");
    $interval = date_diff($datetime1, $datetime2);
    $years = $interval->format('%y')." Years ";
    $months = $interval->format('%m')." Months ";
    $days = $interval->format('%d')." Days ";
    $hours = $interval->format('%h')." Hours ";
    $minutes = $interval->format('%i')." Minutes ";
    if($interval->format('%y') == 1) {
        $years = $interval->format('%y')." Year ";
    }
    if($interval->format('%m') == 1) {
        $months = $interval->format('%m')." Month ";
    }
    if($interval->format('%d') == 1) {
        $days = $interval->format('%d')." Day ";
    }
    if($interval->format('%h') == 1) {
        $hours = $interval->format('%h')." Hour ";
    }
    if($interval->format('%i') == 1) {
        $minutes = $interval->format('%i')." Minute ";
    }
    if($interval->format('%y') == 0) {
        $years = '';
    }
    if($interval->format('%m') == 0) {
        $months = '';
    }
    if($interval->format('%d') == 0) {
        $days = '';
    }
    if($interval->format('%h') == 0) {
        $hours = '';
    }
    if($interval->format('%i') == 0) {
        $minutes = '';
    }
    if($years > 0) {
	$days = '';
        $hours = '';
	$minutes = '';
    }
    if($months > 0) {
	$hours = '';
        $minutes = '';
    }
    if($days > 0) {
	$minutes = '';
    }
    $variance = $interval->format($years.$months.$days.$hours.$minutes.' ago');
    if(strlen($variance) < 5) {
	$variance = " now";
    }
    return $variance;
}
?>
