<?php

/* This is the main config file for rocksolid */

// This is the news server you connect to
$server="example.com";
$port=119;

// Only use these if you post to a different server than you read from
// $post_server="";
// $post_port=119;

// Set to '1' if connecting to a Synchronet server
//$synchronet=1;

// This is the username that you use to log into your news server
// This account must exist on the news server
$server_auth_user="<username>";
$server_auth_pass="<password>";

// This is the usernme that you allow to post as anonymous 
// This account must exist on your local server
// This account is included for testing, you should delete the 
// file /etc/rslight/users/anonymous and create a new account 
// with rslight to replace it. Then enter the new username/password here.
$anonusername="anonymous";
$anonuserpass="8zX\/+q5";
// Important: Please change the above account after testing!

// Set to '1' to allow anonymous posting
$anonuser=1;

// This is added to outgoing message headers
$organization="Unconfigured rslight node";

// This is the 'domain name' added to usernames in outgoing posts
$email_tail="@unconfigured-rslight-node.anon";

// This is displayed above the group names (obsolete)
//$title="Rocksolid - Messages";

// This is displayed above the group list
$title_full="Rocksolid Groups";

// What to tack on the end of a post
$postfooter = "Posted on Unconfigured rslight node";
?>

