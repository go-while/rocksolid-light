<?

include "/etc/rslight/rocksolid.inc.php";
/*
 * directories and files
 */
$spooldir="spool";
$imgdir="img";
$file_newsportal="newsportal.php";
$file_index="index.php";
$file_thread="thread.php";
$file_article="article-flat.php";
$file_article_full="article.php";
$file_attachment="attachment.php";
$file_post="post.php";
$file_cancel="cancel.php";
$file_language="lang/english.lang";
$file_footer="footer.inc";
$file_groups="groups.txt";

if (strpos($_SERVER['HTTP_HOST'], 'onion') !== false) {
        $anonuser=0;
}

/*
 * Grouplist Layout
 */
$gl_age=true;

/*
 * Thread layout
 */
$thread_treestyle=7;
$thread_show["date"]=true;
$thread_show["subject"]=true;
$thread_show["author"]=true;
$thread_show["authorlink"]=false;
$thread_show["replies"]=false;
$thread_show["lastdate"]=true; // makes only sense with $thread_show["replies"]=false
$thread_show["threadsize"]=true;
$thread_maxSubject=70;
$maxarticles=0;
$maxarticles_extra=100;
$age_count=3;
$age_time[1]=86400; //24 hours
$age_color[1]="red";
$age_time[2]=259200; //3 days
$age_color[2]="darkgoldenrod";
$age_time[3]=604800; //7 days
$age_color[3]="darkgreen";
$thread_sort_order=-1;
$thread_sort_type="thread";
$articles_per_page=50;
$startpage="first";

/* 
 * Frames 
 */
$frames_on=true;
// for frames-support: read README in the frames-directory
//$frame_article="article";
//$frame_thread="thread";
//$frame_groups="_top";
//$frame_post="_top";
//$frame_threadframeset="_top";
$frame_externallink="_blank";

/* 
 * article layout 
 */
$article_show["Subject"]=true;
$article_show["From"]=true;
$article_show["Newsgroups"]=false;
$article_show["Followup"]=true;
$article_show["Organization"]=true;
$article_show["Date"]=true;
$article_show["Message-ID"]=false;
$article_show["User-Agent"]=false;
$article_show["References"]=false;
$article_show["From_link"]=true;
//$article_show["From_rewrite"]=array('@',' (at) ');
$article_showthread=true;
$article_graphicquotes=true;

/*
 * settings for the article flat view, if used
 */
$articleflat_articles_per_page=10;
$articleflat_chars_per_articles=5000;

/*
 * Message posting
 */
$send_poster_host=false;
$readonly=false;
$testgroup=true; // don't disable unless you really know what you are doing!
$validate_email=1;
$setcookies=true;
$anonym_address=$anonusername.$email_tail;
$msgid_generate="md5";
$msgid_fqdn=$_SERVER["HTTP_HOST"];
$post_autoquote=false;
$post_captcha=false;

/* 
 * Attachments
 */
$attachment_show=true;
$attachment_delete_alternative=false; // delete non-text mutipart/alternative
$attachment_uudecode=true;  // experimental!

/*
 * Security settings
 */
$block_xnoarchive=false;

/*
 * User registration and database
 */
// $npreg_lib="lib/npreg.inc.php";

/*
 * Cache
 */
$cache_articles=true;  // article cache, experimental!
$cache_index=3600; // cache the group index for one hour before reloading
$cache_thread=60; // cache the thread for one minute reloading

/*
 * Misc 
 */
$cutsignature=true;
$compress_spoolfiles=false;

// website charset, "koi8-r" for example
//$www_charset = "iso-8859-15";
$www_charset = "utf-8";
// Use the iconv extension for improved charset conversions
$iconv_enable=true;
// timezone relative to GMT, +1 for CET
$timezone=+1;

/*
 * Group specific config 
 */
//$group_config=array(
//  '^de\.alt\.fan\.aldi$' => "aldi.inc",
//  '^de\.' => "german.inc"
//);

/*
 * Do not edit anything below this line
 */
// Load group specifig config files
if((isset($group)) && (isset($group_config))) {
  foreach ($group_config as $key => $value) {
    if (ereg($key,$group)) {
      include $value;
      break;
    }
  }
}

// check the settings
include "lib/check.php";

// load the english language definitions first because some of the other
// definitions are incomplete
include("lang/english.lang"); 
include($file_language);
?>
