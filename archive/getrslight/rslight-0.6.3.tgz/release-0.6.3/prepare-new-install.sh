#!/bin/bash
echo
echo "This will prepare the installation for a NEW rslight"
echo "install. If you are upgrading, this will overwrite"
echo "your previous configuration"
echo
echo "If you are upgrading, don't run this and edit and rename"
echo "the files manually as specified in README"
echo
echo "Only answer yes if this is really what you want to do"
echo
read -p "Prepare for NEW rslight install? " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    exit 1
fi
cp index.php.dist index.php
cp common/header.php.dist common/header.php
cp common/rslight.css.dist common/rslight.css
cp common/style.css.dist common/style.css
cp rocksolid/groups.txt.dist rocksolid/groups.txt
cp rocksolid/tail.inc.dist rocksolid/tail.inc
cp rslight/rocksolid.inc.php.dist rslight/rocksolid.inc.php
cp rslight/rslight.inc.php.dist rslight/rslight.inc.php
cp rslight/spoolnews/spoolnews.php.dist rslight/spoolnews/spoolnews.php
cp rslight/spoolnews/groups.txt.dist rslight/spoolnews/groups.txt
echo "Done."

