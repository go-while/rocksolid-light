<?php
/*  rocksolid overboard - overboard for rslight
 *  Version: 0.2
 *  Download: https://news.novabbs.com/getrslight
 *
 *  E-Mail: retroguy@novabbs.com
 *  Web: https://news.novabbs.com
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
?>

<html>
<head>
<title><?php echo "Rocksolid Overboard"?></title>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset==utf-8">
<link rel="stylesheet" type="text/css" href="../common/style.css">
</head>
<body textcolor="black" bgcolor="white">
<?php

include "config.inc.php";

# How many days old should articles be displayed?
$article_age = 7;

# How many characters of the body to display per article
$snippetlength = 240;

# How short of a snippet is ok
$snippetshort = 20;

$spoolpath_regexp = '/'.preg_replace('/\//', '\\/', $spoolpath).'/';
$thissite = '.';

$quotefinder = '>';
if(isset($spoolnews)) {
    $localeol=PHP_EOL.PHP_EOL;
} else {
    $localeol="\r\n\r\n";
}

$articles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($spoolpath.$hierarchy));
echo "<h2 class=np_header>".$hierarchy." overboard</h2>\r\n";
$results=0;
$files = array();
foreach($articles as $article) {
    # Temporarily constrain results to:
    if ($results > 999)
	break;
    if(is_dir($article)) {
	continue;
    }
    $stats = stat($article);
    if($stats[9] < (time() - (86400 * $article_age))) {
	continue;
    }	
    if ((strpos($article, 'rocksolid/admin')) || (strpos($article, 'test')) || (strpos($article, 'rocksolid/feeds'))) {
	continue;
    }
    $files[filemtime($article)] = $article;
}
krsort($files);
foreach($files as $article) {
    $articledata = file_get_contents($article);
    $bodystart = strpos($articledata, $localeol);

    $body = substr($articledata, $bodystart+1);
    $body = substr($body, strpos($body, PHP_EOL));

	if(($multi = strpos($body, 'Content-Type: text/plain')) != false) {
		$bodystart = strpos($body, $localeol);
		$body = substr($body, $bodystart+1);
	    $body = substr($body, strpos($body, PHP_EOL));
	}

    # Find group name and article number
    $group = preg_replace($spoolpath_regexp, '', $article);
    $group = preg_replace('/\//', '.', $group);
    $findme = strrpos($group, '.');
    $groupname = substr($group, 0, $findme);
    $articlenumber = substr($group, $findme+1);

    # Generate link
    $url = $thissite."/article-flat.php?id=".$articlenumber."&group="._rawurlencode($groupname)."#".$articlenumber;
    $groupurl = $thissite."/thread.php?group="._rawurlencode($groupname);
    preg_match('/Subject:.*/', $articledata, $subject);
    $output = explode("Subject: ",$subject[0]);

    preg_match('/Date:.*/', $articledata, $articledate);
    $dateoutput = explode("Date: ",$articledate[0]);

    preg_match('/From:.*/', $articledata, $articlefrom);
    $fromoutput = explode("From: ",$articlefrom[0]);

    echo '<b><a href="'.$url.'">'.mb_decode_mimeheader($output[1])."</a></b><br />\r\n";
    echo '<a href="'.$groupurl.'">'.$groupname.'</a>';
    echo '<p class=np_posted_date>Posted: '.$dateoutput[1].' by: '.mb_decode_mimeheader($fromoutput[1]).'</p>';

    # Try to display useful snippet
	if($stop=strpos($body, "begin 644 "))
		$body=substr($body, 0, $stop);
    $mysnippet = $body;
    if($bodyend=strrpos($mysnippet, "\n---\n")) {
    	$mysnippet = substr($mysnippet, 0, $bodyend);
    } else {
	    if($bodyend=strrpos($mysnippet, "\n-- ")) {
        	$mysnippet = substr($mysnippet, 0, $bodyend);
		} else {
			if($bodyend=strrpos($mysnippet, "\n.")) {
				$mysnippet = substr($mysnippet, 0, $bodyend);
			} 
		}
	}
    if($quoteend=strrpos($mysnippet, $quotefinder)) {
		if($quoteend > (strlen($mysnippet) - $snippetshort)) {
			$quoteend = (strlen($mysnippet) - $snippetlength);
			if ($quoteend < 0)
				$quoteend = 0;
			$mysnippet = substr($mysnippet, $quoteend);
			$mysnippet = substr($mysnippet, strpos($mysnippet, ' '));
		} else {
       		 	$mysnippet = substr($mysnippet, strrpos($mysnippet, $quotefinder) + 1);
	       		$tempsnippet = substr($mysnippet, strpos($mysnippet, PHP_EOL));
			if(strlen($tempsnippet) >= $snippetshort)
				$mysnippet = $tempsnippet;
		}
    }
    $mysnippet = substr($mysnippet, 0, $snippetlength);
    $snippet = $mysnippet."<br /><br />\r\n";
    $displayresult = explode('<', $snippet);
    $echobody=quoted_printable_decode(mb_decode_mimeheader(highlightStr($displayresult[0], $terms)));
    echo $echobody."<br /><br />\r\n";
    $results++;
}
echo "<b>".$results."</b> recent articles found.\r\n";
#echo "<center><i>Rocksolid Overboard</i> version ".$version;
include "tail.inc";


function highlightStr($haystack, $needle) {
    preg_match_all("/$needle+/i", $haystack, $matches);
    if (is_array($matches[0]) && count($matches[0]) >= 1) {
	foreach ($matches[0] as $match) {
	    $haystack = str_replace($match, '<b>'.$match.'</b>', $haystack);
	}
    }
    return $haystack;
}

function _rawurlencode($string) {
    $string = rawurlencode(str_replace('+','%2B',$string));
    return $string;
}

?>
</body>
</html>
