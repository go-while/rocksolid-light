<?php
/*  cron.php 
*  rslight NNTP<->HTTP Gateway
 *  Version: 0.6.x
 *  Download: https://news.novabbs.com/getrslight
 *
 *  Based on Newsportal by Florian Amrhein
 *
 *  E-Mail: retroguy@novabbs.com
 *  Web: https://news.novabbs.com
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

// This file runs maintenance scripts and should be executed by cron regularly
  include "config.inc.php";

  $menulist = file($config_dir."menu.txt", FILE_IGNORE_NEW_LINES);

# Start or verify NNTP server
  if(isset($enable_nntp) && $enable_nntp === true) {
    # Create group list for nntp.php
    $fp1=fopen($spooldir."/".$config_name."/groups.txt", 'w');
      foreach($menulist as $menu) {
      if($menu[0] == '#') {
	continue;
      }
      $menuitem=explode(':', $menu);
      if($menuitem[2] == '1') {
        $in_gl = file($config_dir.$menuitem[0]."/groups.txt");
	foreach($in_gl as $ok_group) {
	  if(($ok_group[0] == ':') || (trim($ok_group) == "")) {
	    continue;
	  }
	  if(strpos($ok_group, "\t") == false) {
	    $ok_group=preg_replace('/ /', "\t", $ok_group, 1);
	  }
	  fputs($fp1, $ok_group);
	}
      }
    }
    fclose($fp1);
    exec($php_exec." ".$config_dir."scripts/nntp.php");
  }
/* Change to non root user */
  $uinfo=posix_getpwnam($webserver_user);
  change_identity($uinfo["uid"],$uinfo["gid"]);
/* Everything below runs as $webserver_user */

  @mkdir($spooldir."/log/",0755,'recursive');

if(isset($enable_nocem) && $enable_nocem == true) {
  @mkdir($spooldir."nocem",0755,'recursive');
  exec($php_exec." ".$config_dir."scripts/nocem.php");
}

reset($menulist);
foreach($menulist as $menu) {
  if(($menu[0] == '#') || (trim($menu) == "")) {
    continue;
  }
  $menuitem=explode(':', $menu);
  chdir("../".$menuitem[0]);
# Send articles
  echo "Sending articles\n";
  echo exec($php_exec." ".$config_dir."scripts/send.php");
# Refresh spool
  if(isset($spoolnews) && ($spoolnews === true)) {
    exec($php_exec." ".$config_dir."scripts/spoolnews.php");
    echo "Refreshed spoolnews\n";
  }
}

function change_identity( $uid, $gid )
    {
        if( !posix_setgid( $gid ) )
        {
            print "Unable to setgid to " . $gid . "!\n";
            exit;
        }

        if( !posix_setuid( $uid ) )
        {
            print "Unable to setuid to " . $uid . "!\n";
            exit;
        }
    }
?>
