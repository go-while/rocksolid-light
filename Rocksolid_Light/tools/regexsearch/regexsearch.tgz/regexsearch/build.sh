#!/bin/bash
echo "Building regexsearch..."
echo "g++ -Wall -fexceptions -O2 -c ./main.cpp -o obj/Release/main.o"
g++ -Wall -fexceptions -O2 -c ./main.cpp -o obj/Release/main.o
echo "g++ -o regexsearch obj/Release/main.o -s -lsqlite3"
g++ -o regexsearch obj/Release/main.o -s -lsqlite3
echo "Created: regexsearch"
echo
echo "You must now configure regexsearch.conf and output/post.sh"
echo "Then run ./regexsearch ./regexsearch.conf"
echo
echo "Verify your nocem output in output/nocem.out"
echo "and Usenet header in output/usenetheader.out"
echo "before running post.sh"

