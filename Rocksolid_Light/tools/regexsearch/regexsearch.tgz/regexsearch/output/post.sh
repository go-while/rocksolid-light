#!/bin/bash

# Config settings
nntp_server=news.i2pn2.org
nntp_username=nntpusername
nntp_password=nntppassword
gpg_password=gpgpassword
gpg_local_user=012345678

# Sign
rm nocem.out.asc
echo "$gpg_password" | /usr/bin/gpg --pinentry-mode loopback --passphrase-fd 0 --local-user "$gpg_local_user" --clearsign -a nocem.out

# Post
rpost $nntp_server -M -U "$nntp_username" -P "$nntp_password" <<%end
$(<usenetheader.out)

$(<nocem.out.asc)
%end
