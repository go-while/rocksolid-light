#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED

#define C_FILENAME 0
#define C_DATABASE_FILE 1
#define C_DATABASE_TABLE 2
#define C_SEARCH_LOCATION 3
#define C_SEARCH_TERM 4

#define C_NOCEM_OUTPUT_PATH 5
#define C_NOCEM_EMAIL_ADDRESS 6
#define C_NOCEM_PUBLIC_KEY 7
#define C_NOCEM_PUBLIC_KEY_URL 8
#define C_NOCEM_INFO 9
#define C_NOCEM_TYPE 10

#define C_HEADER_FOLLOWUP_TO 11
#define C_HEADER_SPAMGROUP 12
#define C_HEADER_ORGANIZATION 13
#define C_HEADER_FROM 14
#define C_HEADER_DOMAIN 15

#define C_SQLITE3_REGEXP 16
#define C_SEARCH_TERM_REGEX 17

void loadConfig()
{
    ifstream configfile;
    string line;
    configfile.open(config[C_FILENAME], ifstream::in);
    while(getline(configfile, line))
    {
        istringstream configfile(line);
        string key, value;
        if(getline(configfile, key, '='))
        {
            if( getline(configfile, value) )
            {
                // Database Info
                if(!key.compare("search_database_file"))
                {
                    config[C_DATABASE_FILE] = value;
                }
                if(!key.compare("search_database_table"))
                {
                    config[C_DATABASE_TABLE] = value;
                }
                if(!key.compare("search_location"))
                {
                    config[C_SEARCH_LOCATION]= value;
                }
                if(!key.compare("search_term"))
                {
                    config[C_SEARCH_TERM] = value;
                }
                if(!key.compare("nocem_output_path"))
                {
                    config[C_NOCEM_OUTPUT_PATH] = value;
                }

                // NoCeM Header Info
                if(!key.compare("nocem_email_address"))
                {
                    config[C_NOCEM_EMAIL_ADDRESS] = value;
                }
                if(!key.compare("nocem_public_key"))
                {
                    config[C_NOCEM_PUBLIC_KEY] = value;
                }
                if(!key.compare("nocem_public_key_url"))
                {
                    config[C_NOCEM_PUBLIC_KEY_URL] = value;
                }
                if(!key.compare("nocem_info_url"))
                {
                    config[C_NOCEM_INFO] = value;
                }
                if(!key.compare("nocem_type"))
                {
                    config[C_NOCEM_TYPE] = value;
                }

                // Usenet Header Info
                if(!key.compare("header_followup_to"))
                {
                    config[C_HEADER_FOLLOWUP_TO] = value;
                }
                if(!key.compare("header_spamgroup"))
                {
                    config[C_HEADER_SPAMGROUP] = value;
                }
                if(!key.compare("header_organization"))
                {
                    config[C_HEADER_ORGANIZATION] = value;
                }
                if(!key.compare("header_from"))
                {
                    config[C_HEADER_FROM] = value;
                }
                if(!key.compare("header_domain"))
                {
                    config[C_HEADER_DOMAIN] = value;
                }

                // Sqlite stuff
                if(!key.compare("sqlite3_regexp"))
                {
                    config[C_SQLITE3_REGEXP] = value;
                }
                if(!key.compare("search_term_regex")) {
                    config[C_SEARCH_TERM_REGEX] = value;
                }
            }
        }
    }
    configfile.close();
}

void createUsenetHeader()
{
    string article;
    extern int count;
    extern string thishash;
    hash<string> hash_string;

    if(count > 1) {
        article = "articles";
    } else {
        article = "article";
    }

    ofstream usenetheaderfile;
    string usenetheader = config[C_NOCEM_OUTPUT_PATH] + "/usenetheader.out";
    remove(usenetheader.c_str());
    usenetheaderfile.open(usenetheader);

    usenetheaderfile << "Message-ID: <" << config[C_NOCEM_TYPE] << "-" << hash_string(thishash) << "@" << config[C_HEADER_DOMAIN] << ">\n";
    if(!config[C_HEADER_FOLLOWUP_TO].empty()) {
        usenetheaderfile << "Followup-To: " << config[C_HEADER_FOLLOWUP_TO] << "\n";
    }
    usenetheaderfile << "From: " << config[C_HEADER_FROM] << "\n";
    usenetheaderfile << "Newsgroups: " << config[C_HEADER_SPAMGROUP] << "\n";
    usenetheaderfile << "Subject: @@NCM NoCeM notice " << config[C_NOCEM_TYPE] << "-" << hash_string(thishash) << " " << config[C_NOCEM_TYPE] << " (" << count << " " << article << ")\n";
    usenetheaderfile << "Content-Type: text/plain; charset=utf-8; format=flowed\n";
    usenetheaderfile << "Content-Transfer-Encoding: 8bit\n";
    usenetheaderfile << "Organization: " << config[C_HEADER_ORGANIZATION] << "\n";

    usenetheaderfile.close();
}

void createNocemHeader()
{
    extern int count;
    extern string thishash;
    hash<string> hash_string;

    nocemheaderfile << "You may use this for hiding articles using NoCeM.\n";
    nocemheaderfile << "These NoCeM notices may cover any hierarchy,\n";
    nocemheaderfile << "and are automatically generated by a script.\n";

    nocemheaderfile << "This message was signed using the following key:\n";
    nocemheaderfile << config[C_NOCEM_PUBLIC_KEY] + "\n\n";

    nocemheaderfile << "The GPG key needed to verify the signature of NoCeM\n";
    nocemheaderfile << "issued by " + config[C_NOCEM_EMAIL_ADDRESS] + " is available at:\n";
    nocemheaderfile << config[C_NOCEM_PUBLIC_KEY_URL] +"\n\n";

    nocemheaderfile << "NoCeM information:\n";
    nocemheaderfile << config[C_NOCEM_INFO] + "\n\n";

    nocemheaderfile << "@@BEGIN NCM HEADERS\n";
    nocemheaderfile << "Version: 0.93\n";
    nocemheaderfile << "Issuer: i2pn2-nocem@i2pn2.org\n";
    nocemheaderfile << "Type: " + config[C_NOCEM_TYPE] + "\n";
    nocemheaderfile << "Action: hide\n";
    nocemheaderfile << "Count: " + to_string(count) + "\n";
    nocemheaderfile << "Notice-ID: " << config[C_NOCEM_TYPE] << "-" << hash_string(thishash);

    return;
}

static int process_query(void* data, int argc, char** argv, char** azColName)
{
    int i;
    size_t j;
    extern int count;
    extern ofstream nocembodyfile;
    vector<string> arr;
    vector<string> clineargs(argv, argv + argc);
    string title, value;
    time_t datetime;

    if(count > 0)
    {
        cout << "\n";
        nocembodyfile << "\n";
    }
    for (i = 0; i < argc; i++)
    {
        string thisarg = clineargs[i];
        string column = azColName[i];
        thisarg.erase(std::remove(thisarg.begin(), thisarg.end(), '\n'), thisarg.end());
        title = column;
        value = thisarg;

        if(column == "name")
        {
            title = "# Sender: ";
        }
        if(column == "subject")
        {
            title = "# Subject: ";
        }
        if(column == "date")
        {
            title = "# Date: ";
            datetime = stoi(thisarg);
            value = ctime(&datetime);
            value.erase(std::remove(value.begin(), value.end(), '\n'), value.end());
        }
        if(column == "msgid")
        {
            string next = clineargs[i+1];
            title = "";
            value = thisarg + " " + next;
        }
        if(column == "newsgroup")
        {
            continue;
        }

        string thisline = title + value;
        arr.push_back(thisline);
    }

    for (j = 0; j < arr.size(); j++)
    {
        cout << arr[j] << "\n";
        nocembodyfile << arr[j] << "\n";
    }
    count ++;
    return 0;
}

#endif // FUNCTIONS_H_INCLUDED
