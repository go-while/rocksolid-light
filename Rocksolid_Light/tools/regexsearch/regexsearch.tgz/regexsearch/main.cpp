#include <stdio.h>
#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <sys/stat.h>
#include <sqlite3.h>

using namespace std;
string config[20];
int count = 0;
ofstream nocemheaderfile;
ofstream nocembodyfile;
string thishash;
#include "functions.h"

int main(int argc, char** argv)
{
    sqlite3* DB;
    char* errMsg;
    int exit = 0;
    bool regexavail;
    extern int count;
    extern string thishash;

    // Find configuration file
    if(argc > 1)
    {
        config[C_FILENAME] = argv[1];
    }
    else
    {
        config[C_FILENAME] = "./regexsearch.conf";
    }
    struct stat sb;
    if (!stat(config[C_FILENAME].c_str(), &sb) == 0)
    {
        cout << " * Configuration File Not Found\n";
        return -1;
    }
    else
    {
        loadConfig();
    }

    if(config[C_SEARCH_TERM].empty() && config[C_SEARCH_TERM_REGEX].empty())
    {
        cout << " * NO SEARCH TERM found in config file.\n";
        return -1;
    }

    string head = config[C_NOCEM_OUTPUT_PATH] + "/nocemheader.txt";
    string body = config[C_NOCEM_OUTPUT_PATH] + "/nocembody.txt";

    remove(head.c_str());
    remove(body.c_str());
    nocemheaderfile.open(head);
    nocembodyfile.open(body);

    exit = sqlite3_open(config[C_DATABASE_FILE].c_str(), &DB);
    if (exit)
    {
        std::cerr << " * Error opening Database " << sqlite3_errmsg(DB) << std::endl;
        return (-1);
    }

    // Enable extension loading
    if (sqlite3_enable_load_extension(DB, 1))
    {
        fprintf(stderr, " * Could not enable extension loading: %s\n", sqlite3_errmsg(DB));
    }

    // Load REGEXP extension
    string regexp_lib_path = config[C_SQLITE3_REGEXP];
    regexp_lib_path.append("/regexp");
    if (sqlite3_load_extension(DB, regexp_lib_path.c_str(), 0, &errMsg))
    {
        fprintf(stderr, " * Could not load REGEXP extension: %s\n * REGEXP features unavailable\n", errMsg);
        sqlite3_free(errMsg);
        regexavail = false;
    }
    else
    {
        fprintf(stdout, " * REGEXP Extension loaded successfully\n * REGEXP features are available\n");
        regexavail = true;
    }

    // Disable further extension loading
    sqlite3_enable_load_extension(DB, 0);

    string data("RESULT");
    string sql;
    if (regexavail == true && !config[C_SEARCH_TERM_REGEX].empty())
    {
        sql = "SELECT name,date,subject,msgid,newsgroup FROM " + config[C_DATABASE_TABLE] + " WHERE " + config[C_SEARCH_LOCATION] + " REGEXP '" + config[C_SEARCH_TERM_REGEX] + "'";
    }
    else
    {
        if(!config[C_SEARCH_TERM].empty())
        {
            sql = "SELECT name,date,subject,msgid,newsgroup FROM " + config[C_DATABASE_TABLE] + " WHERE " + config[C_SEARCH_LOCATION] + " LIKE '%" + config[C_SEARCH_TERM] + "%'";
        }
        else
        {
            cout << " * NO SEARCH TERM (search_term) found in config file.\n";
            return -1;
        }
    }
    nocembodyfile << "\n@@BEGIN NCM BODY\n";

    int rc = sqlite3_exec(DB, sql.c_str(), process_query, (void*)data.c_str(), NULL);
    if (rc != SQLITE_OK)
    {
        cerr << " * SQLITE RESULT CODE: '" << to_string(rc) << "' (https://www.sqlite.org/rescode.html)" << endl;
    }
    nocembodyfile << "@@END NCM BODY\n";
    sqlite3_close(DB);

    if(count < 1)
    {
        cout << " * NO MATCHES\n";
        remove(head.c_str());
        remove(body.c_str());
    }
    else
    {
        string body_string, header_string;
        nocembodyfile.close();
        ifstream nocembodyfile;
        nocembodyfile.open(body);
        string bodydata;
        while (getline(nocembodyfile, bodydata))
        {
            body_string.append(bodydata + "\n");
            thishash.append(bodydata);
        }

        createNocemHeader();

        nocemheaderfile.close();
        string output_file = config[C_NOCEM_OUTPUT_PATH] + "/nocem.out";
        ofstream outputfile;
        outputfile.open(output_file);
        ifstream nocemheaderfile;
        nocemheaderfile.open(head);

        string headdata;
        while (getline(nocemheaderfile, headdata))
        {
            header_string.append(headdata + "\n");
        }

        outputfile << header_string + body_string;
        outputfile.close();
        createUsenetHeader();
        string article;
        if(count > 1)
        {
            article = "articles";
        }
        else
        {
            article = "article";
        }
        cout << " * Listed " << count << " " << article << "\n";
    }
    nocemheaderfile.close();
    nocembodyfile.close();
    return (0);
}

